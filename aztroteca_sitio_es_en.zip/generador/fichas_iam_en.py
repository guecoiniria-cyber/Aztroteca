#!/usr/bin/env python3
"""
Deliverable (English): Mars analog scientific fact sheets for Mexico.

Índices publicados
  IAM  Índice de Analogía Marciana (0–100 %): cercanía de las condiciones medidas a los rangos de referencia de Marte.
  ENA  Escala Nacional de Analogía (1–10): posición de la zona frente a las 921 zonas candidatas del país.
  IIG  Índice de Idoneidad Geoespacial (0–1): índice zonal del análisis SIG (QGIS).

Uso
  python fichas_iam.py --resumen resumen.csv --matriz matriz.csv --qgis carpeta/qgis --salida sitio
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
import sys
from pathlib import Path

import numpy as np

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
sys.path.insert(0, str(AQUI.parent / "fichas"))
import ficha_cientifica as fc  # noqa: E402
import fichas_dae as fd        # noqa: E402

e = fc.e
# ---- English data layer (inserted into fichas_iam_en.py) ----
NAMES_EN = {105: "Montague Island–northern Gore Island"}
DESC_EN = {
    785: "From southeast of Mexicali toward Bladimiro León, Carriso and San Ignacio; spans Baja California and Sonora.",
    105: "Mainly Montague Island and a small part of the northern tip of Gore Island.",
    1397: "From Salvador toward El Mezquitoso and south to La Ballena, in Baja California and Baja California Sur.",
    1218: "Mainly the Alfredo Vladimir Bonfil ejido, Baja California Sur.",
    741: "From Junco to Calamajué, Baja California.",
    1197: "From Bahía Tortugas southeast to La Magnesita, Baja California Sur.",
    1011: "Mainly the Agua de Soda area, Baja California.",
    743: "From San Vicente south to El Ranchito, Baja California.",
    11: "Mainly the Ejido Jacumé area, Baja California.",
    781: "From south of Calamajué toward Asamblea, Baja California.",
}
LUGARES_EN = {
    "Valle de Mexicali (SE de Mexicali), B.C.": "Mexicali Valley (SE of Mexicali), B.C.",
    "Isla Montague": "Montague Island",
    "Punto inicial (corregido: −114.199; el texto dice −144.199)": "Starting point",
    "Sur de Calamajué, B.C.": "South of Calamajué, B.C.",
}
CLASE_EN = {"Análogo alto": "High analog", "Análogo medio-alto": "Medium-high analog",
            "Análogo moderado": "Moderate analog", "Análogo bajo": "Low analog"}

VAR_EN = {  # Spanish name: (English name, Mars reference, method / recommended source)
    "Pendiente local": ("Local slope", "0–5°", "INEGI CEM 15 m (calculation); CONABIO DEM demgw 1 km for context only"),
    "Pendiente transitable P95": ("Traversable slope P95", "0–20°", "INEGI CEM 15 m (calculation); CONABIO DEM demgw 1 km for context only"),
    "Cobertura de rocas ≥0.5 m": ("Rock cover ≥0.5 m", "0–10 %", "Regional proxy: Leptosol and lithic phases in eda250s2gw"),
    "Temperatura máxima diurna de superficie": ("Maximum daytime surface temperature", "−20 to 20 °C", "Validation: Bioclimas bio05 (air temperature, 1 km)"),
    "Temperatura mínima nocturna de superficie": ("Minimum nighttime surface temperature", "−125 to −60 °C", "Validation: Bioclimas bio06 (air temperature, 1 km)"),
    "Irradiancia solar global": ("Global solar irradiance", "150–500 W/m²", "NASA POWER ALLSKY_SFC_SW_DWN; convert kWh/m²/day × 41.667"),
    "Velocidad del viento a ~2 m": ("Wind speed at ~2 m", "2–30 m/s", "NASA POWER WS2M"),
    "Albedo superficial": ("Surface albedo", "0.10–0.30", "MODIS MCD43A3; shortwave albedo"),
    "Pérdida diaria de potencia por polvo": ("Daily power loss from dust", "0–0.5 %/day", "Witness panel test in the field"),
    "Tamaño mediano de grano D50": ("Median grain size D50", "0.003–1 mm", "Sieve or laser diffraction granulometry"),
    "Densidad aparente": ("Bulk density", "1,000–1,600 kg/m³", "Bevelled cylinder or in situ densitometer"),
    "Cohesión": ("Cohesion", "0.1–5 kPa", "Direct shear test"),
    "Ángulo de fricción interna": ("Internal friction angle", "30–40°", "Direct shear or triaxial test"),
    "Capacidad portante": ("Bearing capacity", "100–1,000 kPa", "Plate load test or dynamic penetrometer"),
    "Hundimiento de rueda": ("Wheel sinkage", "0–10 cm", "Test wheel trial"),
    "Percloratos": ("Perchlorates", "0–1 wt%", "Ion chromatography"),
    "Azufre como SO₃": ("Sulfur as SO₃", "5–10 wt%", "Portable X-ray fluorescence"),
    "Actividad de agua (aw)": ("Water activity (aw)", "0–0.6", "Dew point hygrometer"),
    "pH de suelo/salmuera": ("Soil/brine pH", "2–9", "1:5 soil:water extract"),
    "Diámetro de tubo de lava": ("Lava tube diameter", "10–500 m", "LiDAR or cave survey"),
    "Espesor de techo": ("Roof thickness", "2–40 m", "Cave survey + DTM"),
    "Resistencia a compresión ISRU": ("ISRU compressive strength", "10–70 MPa", "Laboratory compression test"),
    "Precipitación media": ("Mean precipitation", "0 mm/day", "Validation: Bioclimas bio12 ÷ 365 (CONABIO, CC BY 4.0, 1 km)"),
    "NDVI": ("NDVI", "0–0.1", "MODIS MOD13A3; scale ×0.0001"),
    "Amplitud térmica diaria": ("Daily temperature range", "40–100 Δ°C", "MYD11A2 day − night; MODIS proxy"),
    "Opacidad atmosférica": ("Atmospheric opacity", "0–2", "MODIS MCD19A2 AOD550; not equivalent to Martian dust"),
    "Contenido de agua en regolito": ("Regolith water content", "2–40 wt%", "Surface SMAP; unit and depth not equivalent"),
    "Litología dominante": ("Dominant lithology", "Basalts/scoria/basaltic sand = 1; intermediate/gypsum = 0.5; granite/limestone/alluvium = 0",
                            "CONABIO hidgeo4mgw (Descripcio contains «basálticas y andesíticas») as a coarse filter; detailed lithology: SGM GeoInfoMex 1:250,000"),
    "Mineralogía de alteración acuosa": ("Aqueous alteration mineralogy", "Smectites, sulfates, carbonates, opal, hematite = 1; related soil proxies = 0.5",
                                         "INEGI Soils Series II eda250s2gw, GRUPO1: Gypsisol→sulfates, Calcisol→carbonates, Vertisol→smectites, Solonchak→salts; EMIT for direct mineralogy"),
    "Textura superficial": ("Surface texture", "Sand/crust = 1; dust-silt or exposed rock = 0.5", "INIFAP-CONABIO soils eda251mgw (texture and physical phase)"),
    "Formas y procesos eólicos": ("Aeolian landforms and processes", "Equivalent landforms = 1; vegetation-fixed dunes = 0",
                                  "Physiographic provinces rfisio4mgw («Desiertos»); Arenosol in eda250s2gw; INEGI landforms"),
    "Tormentas de polvo": ("Dust storms", "Frequent local/regional events = 1", "MERRA-2; event frequency"),
    "Tipo de recurso hídrico": ("Water resource type", "Hydrated minerals = 1; brines/crusts = 0.5; fresh aquifer = 0",
                                "eda250s2gw (Solonchak, Solonetz, saline/sodic phases); RHP rhpri4mgw"),
    "Extremófilos": ("Extremophiles", "Documented group or biosignature = 1", "Context: RTP rtp1mgw, Ramsar ramsar15gw and SNIB records"),
    "Biofirmas objetivo": ("Target biosignatures", "Documented biosignature = 1", "Literature and sampling"),
    "Tipo de cavidad": ("Cavity type", "Lava tube/skylight/gypsum cave = 1; karstic = 0.5", "Speleological inventories and INEGI geology"),
    "Estabilidad del techo": ("Roof stability", "Stable = 1; fractured/metastable = 0.5", "Geotechnical field inspection"),
    "Gravedad superficial": ("Surface gravity", "3.71 m/s²", ""),
    "Presión atmosférica": ("Atmospheric pressure", "400–1,000 Pa", ""),
    "Densidad atmosférica": ("Atmospheric density", "0.01–0.02 kg/m³", ""),
    "Composición atmosférica": ("Atmospheric composition", "~95 % CO₂", ""),
    "Radiación UV-C en superficie": ("Surface UV-C radiation", "Reaches the ground due to lack of ozone", ""),
    "Campo magnético global": ("Global magnetic field", "Absent; local crustal magnetization", ""),
    "Dosis de radiación": ("Radiation dose", "10–100 mSv/year under shielding or in caves", ""),
    "Duración del día solar": ("Length of the solar day", "24.66 h", ""),
    "Elevación sobre datum MOLA": ("Elevation above MOLA datum", "Preferred −5,000 to 0 m; limit +2 km", ""),
    "Latitud del sitio": ("Site latitude", "−50° to +50°", ""),
    "Profundidad de hielo somero": ("Shallow ice depth", "0–5 m", ""),
    "Fracción de hielo subsuperficial": ("Subsurface ice fraction", "20–90 % vol", ""),
}


def VT(v):
    return VAR_EN.get(v, (v, "", ""))[0]


def RT(v):
    return VAR_EN.get(v, (v, v, ""))[1]


def MT(v):
    return VAR_EN.get(v, (v, "", ""))[2]


def _escala_en(nota):
    return (fd.escala_html(nota).replace(">Bajo &lt; 5<", ">Low &lt; 5<").replace(">Moderado 5–7<", ">Moderate 5–7<")
            .replace(">Medio-alto 7–9<", ">Medium-high 7–9<").replace(">Alto ≥ 9<", ">High ≥ 9<"))


def a_ingles(fichas):
    """Translate zone-level text after the calculations, without changing any number."""
    for f in fichas:
        f["nombre"] = NAMES_EN.get(f["fid"], f["nombre"])
        f["descripcion"] = DESC_EN.get(f["fid"], f["descripcion"])
        f["clase_nac"] = CLASE_EN.get(f["clase_nac"], f["clase_nac"])
        for L in f["lugares"]:
            L["nombre"] = LUGARES_EN.get(L["nombre"], L["nombre"])


# --------------------------------------------------------------------------------------------
# Catálogo de variables con dato (explicación pública)
# --------------------------------------------------------------------------------------------
VARS = {
    "precip": dict(nombre="Mean precipitation", unidad="mm/day", fuente="NASA GPM IMERG", res="0.1° (~10 km), resampled to ~1 km",
                   que="Average daily rainfall over the zone.",
                   marte="0 mm/day. It does not rain on Mars and liquid water is not stable at the surface.",
                   porque="A hyperarid site preserves dry soils, salts and Mars-like surfaces, and allows equipment to be tested without moisture.",
                   ventana="0 mm/day", puntua=True, peso="30 %"),
    "ndvi": dict(nombre="Vegetation index (NDVI)", unidad="dimensionless", fuente="NASA MODIS MOD13A3", res="1 km",
                 que="Measures plant greenness. Values of 0.1 or less indicate rock, sand or bare soil.",
                 marte="0 to 0.1. Mars has no vegetation.",
                 porque="Rover, landing and habitat tests need bare surfaces like those on Mars.",
                 ventana="0 to 0.1", puntua=True, peso="30 %"),
    "rango": dict(nombre="Daily temperature range", unidad="°C", fuente="NASA MODIS MYD11A2 (land surface temperature, day − night)", res="1 km",
                  que="Difference between daytime and nighttime surface temperature.",
                  marte="40 to 100 °C daily swing.",
                  porque="Strong thermal cycles wear out materials, seals, batteries and electronics.",
                  ventana="40 to 100 °C", puntua=True, peso="40 %"),
    "polvo": dict(nombre="Atmospheric dust", unidad="relative index", fuente="NASA MERRA-2", res="0.5° × 0.625° (~50 km), resampled",
                  que="Dust concentration in the air near the surface.",
                  marte="Permanent dust, with local, regional and global storms.",
                  porque="Allows testing of solar panel cleaning and protection of seals and optics.",
                  ventana="Context (not scored)", puntua=False, peso="not part of the calculation; reported as context"),
}

# Áreas naturales protegidas (fuentes públicas; confirmar traslape con la capa federal de CONANP)
ANP = {
    785: "Borders the Upper Gulf of California and Colorado River Delta Biosphere Reserve (Mexicali and San Luis Río Colorado). Overlap and permits must be confirmed with CONANP.",
    105: "Montague Island lies within the Upper Gulf of California and Colorado River Delta Biosphere Reserve and among the Gulf of California islands recognized by UNESCO. Fieldwork requires CONANP permits.",
    741: "Lies in the 28°–30° N band of Baja California covered by the Valle de los Cirios Flora and Fauna Protection Area. CONANP permits are probably required.",
    781: "Lies in the 28°–30° N band of Baja California covered by the Valle de los Cirios Flora and Fauna Protection Area. CONANP permits are probably required.",
    1011: "Lies in the 28°–30° N band of Baja California covered by the Valle de los Cirios Flora and Fauna Protection Area. CONANP permits are probably required.",
    743: "Lies near the northwestern boundary of the Valle de los Cirios Flora and Fauna Protection Area. Overlap must be confirmed with CONANP.",
    1397: "Spans the Valle de los Cirios band (Baja California) and the municipality of Mulegé, home to the El Vizcaíno Biosphere Reserve. Likely overlaps both areas.",
    1197: "Bahía Tortugas is a community inside the El Vizcaíno Biosphere Reserve. Fieldwork requires CONANP permits.",
    1218: "Lies in the municipality of Mulegé, most of which belongs to the El Vizcaíno Biosphere Reserve. Overlap must be confirmed with CONANP.",
}
ISLA = {105: "A sedimentary island at the mouth of the Colorado River: access is by sea only and the terrain is tide-influenced."}


def lcf(t):
    return t if t[:2].isupper() else t[:1].lower() + t[1:]


def clase_iam(i):
    return "high" if i >= 80 else "moderate" if i >= 60 else "partial" if i >= 40 else "weak"


# --------------------------------------------------------------------------------------------
# Cálculos adicionales
# --------------------------------------------------------------------------------------------
def enriquecer(fichas, args):
    nac = fd.leer_csv(args.qgis / "ranking_zonas.csv")
    iam_nac = np.array([fd.dae(float(z["lluvia_mean"]), float(z["ndvi_mean"]), float(z["rango_mean"])) for z in nac])
    for f in fichas:
        zs = f["zonal"]
        P3 = [zs["precip"]["p5"], f["P"], zs["precip"]["p95"]]
        N3 = [zs["ndvi"]["p5"], f["Nd"], zs["ndvi"]["p95"]]
        T3 = [zs["rango"]["p5"], f["T"], zs["rango"]["p95"]]
        W = (0.27, 0.30, 0.33)
        espacial = [fd.dae(p, n, t) for p, n, t in itertools.product(P3, N3, T3)]
        pesos = [fd.dae(f["P"], f["Nd"], f["T"], wp, wn) for wp, wn in itertools.product(W, W)]
        ambas = [fd.dae(p, n, t, wp, wn) for p, n, t, wp, wn in itertools.product(P3, N3, T3, W, W)]
        f["int"] = {"espacial": (min(espacial), max(espacial)), "pesos": (min(pesos), max(pesos)), "ambas": (min(ambas), max(ambas))}
        lo, hi = f["int"]["ambas"]

        def nota_de(iam):
            return 1 + 9 * (f["P_qgis"] + 100 * float(np.mean(iam_nac < iam))) / 200
        f["ena_int"] = (nota_de(lo), nota_de(hi))
        f["pct_top"] = (f["P_qgis"] + f["P_dae"]) / 2
        # fortalezas por variable (0–1) y percentil nacional "a favor de Marte"
        n = f["nac"]
        f["vars"] = [
            {"k": "ndvi", "valor": f"{f['Nd']:.3f}", "s": f["sN"], "pct": n["ndvi"]["pct_mas_verdes"],
             "pct_txt": f"Less vegetation than {n['ndvi']['pct_mas_verdes']:.0f} % of the country's zones"},
            {"k": "precip", "valor": f"{f['P']:.2f} mm/day", "s": f["sP"], "pct": n["precip"]["pct_mas_humedas"],
             "pct_txt": f"Drier than {n['precip']['pct_mas_humedas']:.0f} % of the country's zones"},
            {"k": "rango", "valor": f"{f['T']:.1f} °C", "s": f["sT"], "pct": n["rango"]["pct_menor"],
             "pct_txt": f"Larger range than {n['rango']['pct_menor']:.0f} % of the country's zones"},
            {"k": "polvo", "valor": f"{f['Pv'] * 1e8:.2f} × 10⁻⁸", "s": None, "pct": n["polvo"]["pct_menor"],
             "pct_txt": f"More dust than {n['polvo']['pct_menor']:.0f} % of the country's zones"},
        ]
        f["vars"].sort(key=lambda v: (-(v["s"] if v["s"] is not None else -1), -v["pct"]))
        f["favor"], f["limit"] = puntos(f)
    return iam_nac


def puntos(f):
    n = f["nac"]; fav, lim = [], []
    if f["nota"] >= 9:
        fav.append(("Among the most analogous zones in Mexico", f"On the National Scale it outranks {f['pct_top']:.1f} % of the 921 candidate zones in Mexico."))
    if f["Nd"] <= 0.1:
        fav.append(("Practically bare surface", f"NDVI of {f['Nd']:.3f}, within the Mars reference range (0.1 or less)."))
    elif f["Nd"] <= 0.13:
        fav.append(("Very sparse vegetation", f"NDVI of {f['Nd']:.3f}, very close to the Mars reference range (0.1 or less)."))
    if n["precip"]["pct_mas_humedas"] >= 90:
        fav.append(("Hyperaridity", f"{f['P']:.2f} mm/day of rainfall: drier than {n['precip']['pct_mas_humedas']:.0f} % of the candidate zones."))
    if n["polvo"]["pct_menor"] >= 80:
        fav.append(("Abundant atmospheric dust", f"More dust than {n['polvo']['pct_menor']:.0f} % of the zones: a good setting to test dust mitigation on panels, seals and optics."))
    if n["rango"]["pct_menor"] >= 75:
        fav.append(("High thermal swing for Mexico", f"{f['T']:.1f} °C per day, larger than in {n['rango']['pct_menor']:.0f} % of the zones."))
    if f["area_km2"] >= 1000:
        fav.append(("Large area", f"{f['area_km2']:,.0f} km² for long rover traverses and infrastructure deployment."))
    elif f["geo"]["extension_km"] >= 10:
        fav.append(("Enough extent for landings", f"{f['geo']['extension_km']:.1f} km maximum extent, enough for a landing ellipse of up to 10 km."))
    if abs(f["lat"]) <= 28:
        fav.append(("Favorable latitude for launches", f"{f['lat']:.2f}° N, within the 0–28° range that makes best use of Earth's rotation."))
    if f["lugares"]:
        nom = ", ".join(L["nombre"].split(" (")[0] for L in f["lugares"][:3])
        fav.append(("Reference localities inside the zone", f"{nom}: access points for fieldwork."))
    lim.append(("Smaller thermal swing than Mars", f"{f['T']:.1f} °C versus a 40 °C minimum on Mars. This is the largest difference from Mars and takes {40 - f['aportes']['Amplitud térmica']:.1f} points off the MAI."))
    if f["Nd"] > 0.13:
        lim.append(("Some vegetation", f"NDVI of {f['Nd']:.3f}, above the Mars reference range (0.1 or less)."))
    if n["precip"]["pct_mas_humedas"] < 50:
        lim.append(("More rain than the average candidate", f"{f['P']:.2f} mm/day: wetter than half of the country's zones."))
    if f["area_km2"] < 100:
        lim.append(("Small area", f"{f['area_km2']:.0f} km², little room for large-scale operations or long traverses."))
    if f["fid"] in ISLA:
        lim.append(("Sea access", ISLA[f["fid"]]))
    if f["fid"] in ANP:
        lim.append(("Protected natural area", ANP[f["fid"]]))
    if f["rank_dae_nac"] > 100:
        lim.append(("Low Mars analogy for the country", f"Its MAI places it {f['rank_dae_nac']} of {f['N']}: vegetation and rainfall pull it away from Mars."))
    lim.append(("Variables still to measure", "34 of the 37 comparable variables (geology, soil, mineralogy, slope, caves) have no data yet and require official layers or field campaigns."))
    return fav, lim


# --------------------------------------------------------------------------------------------
# Estilos y scripts adicionales
# --------------------------------------------------------------------------------------------
CSS2 = r"""
.brand .logo{height:32px;width:auto;margin-right:4px}footer .b .logo{height:22px;width:auto;margin-right:2px}
.imap .z-pl{fill:#fff;stroke:#c1440e;stroke-width:1.2;cursor:help}
.lead-x{font-size:18px;color:var(--ink2);max-width:760px;line-height:1.6;margin:0}
.explain{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:22px}
.step{padding:22px 24px;position:relative}.step .k{font:700 34px var(--disp);color:var(--burn);line-height:1}
.step h4{font:600 16px var(--disp);margin:10px 0 6px}.step p{font-size:13.5px;color:var(--ink2);margin:0;line-height:1.55}
.defs{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.def{padding:24px}.def .ac{font:700 13px var(--mono);letter-spacing:.14em;color:var(--burn)}.def h4{font:700 20px var(--disp);margin:6px 0 10px}
.def p{font-size:13.5px;color:var(--ink2);margin:0 0 8px;line-height:1.55}.def .rg{font:500 12px var(--mono);color:var(--mut);border-top:1px solid var(--line);padding-top:10px;margin-top:12px}
.fv{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.fl{padding:26px}.fl h3{display:flex;align-items:center;gap:10px;font:600 19px var(--disp);margin:0 0 16px}
.fl h3 i{width:12px;height:12px;border-radius:50%}.fl.ok h3 i{background:var(--ok);box-shadow:0 0 12px var(--ok)}.fl.bad h3 i{background:var(--bad);box-shadow:0 0 12px var(--bad)}
.fl .it{padding:14px 0;border-top:1px solid var(--line)}.fl .it:first-of-type{border-top:0}
.fl .it b{display:block;font:600 14.5px var(--disp);margin-bottom:3px}.fl .it span{font-size:13.5px;color:var(--ink2);line-height:1.55}
.vc-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}
.vc{padding:22px 24px;cursor:pointer;transition:.25s;position:relative}
.vc:hover{border-color:rgba(224,120,47,.5);transform:translateY(-2px)}
.vc .rk{position:absolute;top:18px;right:20px;font:700 12px var(--mono);color:var(--mut2);padding:0;border:0;display:block}
.vc .rk.top{color:var(--ok)}
.vc h4{font:600 17px var(--disp);margin:0 0 4px;padding-right:60px}.vc .src{display:block;font-size:12px;color:var(--mut);background:none;border:0;padding:0;margin:0}
.vc .nums{display:flex;align-items:baseline;gap:14px;margin:14px 0 6px}.vc .nums b{font:700 30px var(--disp)}.vc .nums span{font:500 12px var(--mono);color:var(--mut)}
.vc .two{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px}
.vc .two div{font:600 10.5px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:var(--mut2)}
.vc .more{display:none;margin-top:16px;padding-top:14px;border-top:1px solid var(--line);font-size:13.5px;color:var(--ink2);line-height:1.6}
.vc .more p{margin:0 0 8px}.vc .more b{color:var(--ink)}
.vc.open .more{display:block}.vc .hint{font:500 11px var(--mono);color:var(--mut2);margin-top:12px}
.vc.open .hint{display:none}
.ci{padding:28px 30px}
.ci-tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:26px}
.ci-tabs button{font:500 13px var(--body);color:var(--ink2);background:var(--bg2);border:1px solid var(--line);padding:9px 14px;border-radius:10px;cursor:pointer;transition:.2s}
.ci-tabs button.on{color:var(--ink);border-color:var(--burn);background:rgba(193,68,14,.15)}
.ci-plot{position:relative;height:74px;margin:10px 0 4px}
.ci-plot .ax{position:absolute;left:0;right:0;top:36px;height:2px;background:var(--line2)}
.ci-plot .bandx{position:absolute;top:26px;height:22px;border-radius:7px;background:rgba(224,120,47,.28);border:1px solid rgba(224,120,47,.7);transition:left .5s,width .5s}
.ci-plot .ptx{position:absolute;top:22px;width:4px;height:30px;background:#fff;border-radius:2px;transform:translateX(-2px)}
.ci-plot .lab{position:absolute;top:0;font:600 12px var(--mono);transform:translateX(-50%);white-space:nowrap;transition:left .5s}
.ci-ax{display:flex;justify-content:space-between;font:500 11px var(--mono);color:var(--mut2)}
.ci-txt{font-size:14px;color:var(--ink2);margin:18px 0 0;line-height:1.6}
.ci-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:14px}
.ci-grid .card{padding:20px 22px}.ci-grid .l{font:600 11px var(--mono);letter-spacing:.14em;text-transform:uppercase;color:var(--mut)}
.ci-grid .v{font:700 28px var(--disp);margin:8px 0 4px}.ci-grid p{font-size:13px;color:var(--ink2);margin:0}
.zmap{display:grid;grid-template-columns:1.4fr 1fr;gap:16px}
.zsvg{width:100%;height:auto;display:block}.zsvg .nb{fill:rgba(255,255,255,.07);stroke:rgba(255,255,255,.12);stroke-width:.4}
.zsvg .me{fill:rgba(193,68,14,.55);stroke:#ffd9c4;stroke-width:1}
.zsvg .lm circle{fill:#fff;stroke:#c1440e;stroke-width:2;cursor:pointer;transition:r .2s}.zsvg .lm:hover circle{r:8}
.zsvg .lm text{font:600 12px var(--body);fill:var(--ink);paint-order:stroke;stroke:#07080a;stroke-width:4px}
.zsvg .scl{stroke:var(--ink2);stroke-width:2}.zsvg .sct{font:500 11px var(--mono);fill:var(--ink2)}
.gloss{border-bottom:1px dotted var(--mut);cursor:help}
.srcs{display:grid;grid-template-columns:1.3fr 1fr;gap:16px}
.srcs h4{font:600 12px var(--mono);letter-spacing:.16em;text-transform:uppercase;color:var(--mut);margin:0 0 12px}
.srcs ul{list-style:none;margin:0;padding:0}.srcs li{padding:10px 0;border-top:1px solid var(--line);font-size:13.5px;color:var(--ink2);line-height:1.5}
.srcs li:first-child{border-top:0}.srcs li b{color:var(--ink);font-weight:600}.srcs a{color:var(--burn);text-decoration:none}.srcs a:hover{text-decoration:underline}
.sw-list .tag{display:inline-block;font:600 10.5px var(--mono);color:var(--burn);background:rgba(193,68,14,.12);padding:3px 8px;border-radius:6px;margin-right:8px}
.tbl{width:100%;border-collapse:collapse;font-size:13.5px}
.tbl th{font:600 10.5px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--mut2);text-align:left;padding:14px 16px;border-bottom:1px solid var(--line);background:var(--bg2);cursor:pointer;user-select:none;white-space:nowrap}
.tbl th:hover{color:var(--ink)}.tbl th.sorted{color:var(--burn)}.tbl th .ar{margin-left:6px;opacity:.6}
.tbl td{padding:14px 16px;border-bottom:1px solid var(--line);font-family:var(--mono);font-size:13px;white-space:nowrap}
.tbl td.nm{font-family:var(--body);font-weight:600;white-space:normal}.tbl td.nm a{text-decoration:none}.tbl td.nm a:hover{color:var(--burn)}
.tbl tr{transition:background .2s}.tbl tbody tr:hover{background:rgba(255,255,255,.03)}
.tbl .cl{font:600 11.5px var(--body);padding:4px 10px;border-radius:999px}
.cl.alto{color:var(--ok);background:var(--okbg)}.cl.medio{color:var(--burn);background:rgba(224,120,47,.14)}.cl.mod{color:var(--mid);background:var(--midbg)}.cl.bajo{color:var(--bad);background:var(--badbg)}
.sim{display:grid;grid-template-columns:320px 1fr;gap:20px}
.sim .ctl{padding:24px}.sim .ctl label{display:block;font:600 12px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:var(--mut);margin:18px 0 8px}
.sim .ctl label:first-of-type{margin-top:0}.sim .ctl label b{float:right;color:var(--ink);font-size:14px}
.sim input[type=range]{width:100%;accent-color:#e0782f}
.sim .note{font-size:12.5px;color:var(--mut);margin-top:18px;line-height:1.55}
.sim .res{padding:20px 24px}.sbar{display:grid;grid-template-columns:28px 1fr 60px;gap:12px;align-items:center;padding:8px 0;transition:transform .4s}
.sbar .n{font:700 14px var(--disp);color:var(--burn)}.sbar .t{font-size:13.5px}.sbar .t small{display:block;color:var(--mut);font-size:11.5px}
.sbar .b{height:8px;background:rgba(255,255,255,.07);border-radius:9px;overflow:hidden;margin-top:6px}.sbar .b i{display:block;height:100%;background:linear-gradient(90deg,#c1440e,#e0782f);transition:width .4s}
.sbar .v{font:700 15px var(--disp);text-align:right}.sbar .d{font:500 11px var(--mono)}
.cmp{padding:26px}.cmp .sel{display:grid;grid-template-columns:1fr auto 1fr;gap:14px;align-items:center;margin-bottom:22px}
.cmp select{font:500 14px var(--body);color:var(--ink);background:var(--bg2);border:1px solid var(--line2);padding:10px 12px;border-radius:10px;width:100%}
.cmp .vs{font:700 14px var(--mono);color:var(--mut)}
.crow{display:grid;grid-template-columns:1fr 150px 1fr;gap:14px;align-items:center;padding:10px 0;border-top:1px solid var(--line)}
.crow .c{font:600 11px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:var(--mut);text-align:center}
.crow .a,.crow .bb{display:flex;align-items:center;gap:10px}.crow .a{flex-direction:row-reverse}
.crow .bar2{flex:1;height:10px;background:rgba(255,255,255,.06);border-radius:9px;overflow:hidden;display:flex}
.crow .a .bar2{justify-content:flex-end}.crow .bar2 i{display:block;height:100%;transition:width .5s}
.crow .a .bar2 i{background:#e0782f}.crow .bb .bar2 i{background:#8fb3ff}
.crow .val{font:600 13px var(--mono);min-width:76px}.crow .a .val{text-align:right}
.crow .val.w{color:var(--ok)}
.tipbox{position:fixed;z-index:70;pointer-events:none;background:#1b1f27;border:1px solid var(--line2);border-radius:12px;padding:10px 14px;font-size:13px;color:var(--ink2);box-shadow:0 18px 40px -10px #000;opacity:0;transition:opacity .15s;max-width:280px}
.tipbox.on{opacity:1}.tipbox b{display:block;color:var(--ink);font:600 14px var(--disp);margin-bottom:3px}
.imap .z-top{cursor:pointer;transition:fill .2s}.imap .z-top:hover{fill:rgba(224,120,47,.85)}
.pending{columns:2;column-gap:28px}.pending .pg{break-inside:avoid;margin-bottom:18px}
.pending h5{font:600 12px var(--mono);letter-spacing:.14em;text-transform:uppercase;color:var(--burn);margin:0 0 8px}
.pending li{font-size:13.5px;color:var(--ink2);padding:6px 0;border-top:1px solid var(--line);list-style:none}.pending ul{margin:0;padding:0}
.pending li b{color:var(--ink);font-weight:600}.pending li span{display:block;font-size:12px;color:var(--mut)}
@media (max-width:980px){.explain,.defs,.fv,.vc-grid,.ci-grid,.zmap,.srcs,.sim{grid-template-columns:1fr}.pending{columns:1}
 .cmp .sel{grid-template-columns:1fr}.crow{grid-template-columns:1fr 78px 1fr;gap:8px}.crow .val{min-width:0;font-size:11.5px}.crow .bar2{min-width:36px}.tbl-wrap{overflow-x:auto}}
"""

JS_FICHA = r"""
(function(){
  const $=(s,c=document)=>c.querySelector(s),$$=(s,c=document)=>[...c.querySelectorAll(s)];
  $$('.vc').forEach(c=>c.addEventListener('click',()=>c.classList.toggle('open')));
  const ci=window.__CI;
  if(ci){
    const lo=ci.axis[0],hi=ci.axis[1],P=v=>((v-lo)/(hi-lo)*100).toFixed(2)+'%';
    const band=$('.bandx'),l1=$('#ci-lo'),l2=$('#ci-hi'),t=$('#ci-t');
    $('.ptx').style.left=P(ci.iam);
    function set(k){const [a,b]=ci[k];band.style.left=P(a);band.style.width=(((b-a)/(hi-lo))*100).toFixed(2)+'%';
      l1.style.left=P(a);l1.textContent=a.toFixed(1)+' %';l2.style.left=P(b);l2.textContent=b.toFixed(1)+' %';
      t.innerHTML=ci.txt[k];$$('.ci-tabs button').forEach(x=>x.classList.toggle('on',x.dataset.k===k));}
    $$('.ci-tabs button').forEach(b=>b.addEventListener('click',()=>set(b.dataset.k)));set('ambas');
  }
  const tip=$('.tipbox');
  $$('[data-tt]').forEach(el=>{el.addEventListener('mousemove',ev=>{tip.innerHTML=el.dataset.tt;tip.classList.add('on');
    tip.style.left=Math.min(ev.clientX+14,innerWidth-300)+'px';tip.style.top=(ev.clientY+14)+'px'});
    el.addEventListener('mouseleave',()=>tip.classList.remove('on'));});
})();
"""

JS_INDEX = r"""
(function(){
  const $=(s,c=document)=>c.querySelector(s),$$=(s,c=document)=>[...c.querySelectorAll(s)];
  const Z=window.__Z;
  // tabla ordenable
  const tb=$('#rank tbody');let dir={};
  $$('#rank th[data-k]').forEach(th=>th.addEventListener('click',()=>{const k=th.dataset.k;dir[k]=dir[k]===-1?1:-1;
    const rows=[...tb.rows].sort((a,b)=>{const x=a.dataset[k],y=b.dataset[k];const nx=parseFloat(x),ny=parseFloat(y);
      return (isNaN(nx)?x.localeCompare(y):nx-ny)*dir[k]});rows.forEach(r=>tb.appendChild(r));
    $$('#rank th').forEach(h=>{h.classList.toggle('sorted',h===th);const ar=h.querySelector('.ar');if(ar)ar.textContent=h===th?(dir[k]===1?'▲':'▼'):''});}));
  $$('.fchip').forEach(b=>b.addEventListener('click',()=>{const c=b.dataset.c,on=!b.classList.contains('on');
    $$('.fchip').forEach(x=>x.classList.remove('on'));if(on)b.classList.add('on');
    [...tb.rows].forEach(r=>r.style.display=(!on||r.dataset.cls===c)?'':'none');}));
  // simulador de pesos
  const sP=$('#wP'),sN=$('#wN');
  function sc(p,n,t,wp,wn){const wt=1-wp-wn;const a=Math.max(0,1-p/2),b=n<=0.1?1:Math.max(0,1-(n-0.1)/0.3),c=(t>=40&&t<=100)?1:Math.max(0,1-(t<40?40-t:t-100)/60);return 100*(wp*a+wn*b+wt*c)}
  function sim(){let wp=+sP.value/100,wn=+sN.value/100;if(wp+wn>0.95){wn=0.95-wp;sN.value=Math.round(wn*100)}
    $('#vP').textContent=Math.round(wp*100)+' %';$('#vN').textContent=Math.round(wn*100)+' %';$('#vT').textContent=Math.round((1-wp-wn)*100)+' %';
    const r=Z.map(z=>({z,v:sc(z.P,z.N,z.T,wp,wn)})).sort((a,b)=>b.v-a.v);const box=$('#simres');box.innerHTML='';
    r.forEach((o,i)=>{const d=(z=>z.rank_iam10)(o.z)-(i+1);const el=document.createElement('div');el.className='sbar';
      el.innerHTML=`<span class="n">${String(i+1).padStart(2,'0')}</span><span class="t">${o.z.nombre}<small>${d===0?'same position':(d>0?'▲ up '+d:'▼ down '+(-d))}</small><span class="b"><i style="width:${o.v.toFixed(1)}%"></i></span></span><span class="v">${o.v.toFixed(1)}%</span>`;box.appendChild(el)});}
  if(sP){sP.addEventListener('input',sim);sN.addEventListener('input',sim);$('#wreset').addEventListener('click',()=>{sP.value=30;sN.value=30;sim()});sim();}
  // comparador
  const A=$('#cA'),B=$('#cB');
  const MET=[['ena','National scale',10,v=>v.toFixed(2),1],['iam','MAI',100,v=>v.toFixed(1)+' %',1],['iig','GIS suitability',1,v=>v.toFixed(3),1],
    ['sP','Aridity (score)',1,v=>(v*100).toFixed(0)+' %',1],['sN','No vegetation (score)',1,v=>(v*100).toFixed(0)+' %',1],['sT','Temp. range (score)',1,v=>(v*100).toFixed(0)+' %',1],
    ['P','Rain mm/day',1.5,v=>v.toFixed(2),-1],['N','NDVI',0.25,v=>v.toFixed(3),-1],['T','Temp. range °C',25,v=>v.toFixed(1),1],['area','Area km²',null,v=>Math.round(v).toLocaleString('en-US'),1]];
  function cmp(){const a=Z[A.value],b=Z[B.value];const box=$('#cmpres');box.innerHTML='';
    MET.forEach(([k,lab,mx,f,better])=>{const va=a[k],vb=b[k];const m=mx||Math.max(va,vb);const wa=better*(va-vb)>0,wb=better*(vb-va)>0;
      const el=document.createElement('div');el.className='crow';
      el.innerHTML=`<div class="a"><span class="val ${wa?'w':''}">${f(va)}</span><span class="bar2"><i style="width:${Math.min(100,va/m*100)}%"></i></span></div><div class="c">${lab}</div><div class="bb"><span class="bar2"><i style="width:${Math.min(100,vb/m*100)}%"></i></span><span class="val ${wb?'w':''}">${f(vb)}</span></div>`;box.appendChild(el)});}
  if(A){Z.forEach((z,i)=>{A.add(new Option(z.nombre,i));B.add(new Option(z.nombre,i))});A.value=0;B.value=Math.min(1,Z.length-1);A.onchange=cmp;B.onchange=cmp;cmp();}
  // mapa interactivo
  const tip=$('.tipbox');
  $$('[data-tt]').forEach(el=>{el.addEventListener('mousemove',ev=>{tip.innerHTML=el.dataset.tt;tip.classList.add('on');
    tip.style.left=Math.min(ev.clientX+14,innerWidth-300)+'px';tip.style.top=(ev.clientY+14)+'px'});
    el.addEventListener('mouseleave',()=>tip.classList.remove('on'));
    if(el.dataset.href)el.addEventListener('click',()=>location.href=el.dataset.href);});
})();
"""


# --------------------------------------------------------------------------------------------
# Fuentes y software (compartido)
# --------------------------------------------------------------------------------------------
FUENTES_DATOS = [
    ("NASA GPM IMERG", "Precipitation (0.1°).", "https://gpm.nasa.gov/data/imerg"),
    ("NASA MODIS MOD13A3", "Monthly NDVI vegetation index (1 km).", "https://appeears.earthdatacloud.nasa.gov"),
    ("NASA MODIS MYD11A2", "Day and night land surface temperature (1 km).", "https://appeears.earthdatacloud.nasa.gov"),
    ("NASA MERRA-2", "Atmospheric dust (reanalysis).", "https://giovanni.gsfc.nasa.gov"),
    ("NASA Earthdata", "Access to satellite products.", "https://earthdata.nasa.gov"),
]
FUENTES_MARTE = [
    ("NASA Mars Fact Sheet", "Gravity, pressure, atmospheric density and length of the Martian day.", "https://nssdc.gsfc.nasa.gov"),
    ("NASA Mars Design Reference Architecture 5.0 (NASA-SP-2009-566)", "Bearing capacity, power, navigation and radiation dose.", "https://ntrs.nasa.gov"),
    ("NASA, Exploration Zones for human missions (2016)", "Reference domain: latitude ±50°, elevation ≤ +2 km.", "https://ntrs.nasa.gov/api/citations/20160002370/downloads/20160002370.pdf"),
    ("SWIM – Subsurface Water Ice Mapping (NASA/PSI)", "Shallow ice and ice fraction.", "https://swim.psi.edu/"),
    ("Mars Climate Database (LMD/ESA/CNES)", "Temperature, wind, dust and irradiance on Mars.", "https://www-mars.lmd.jussieu.fr/mars/access.html"),
    ("REMS, Curiosity (PDS Atmospheres)", "Surface weather measurements.", "https://pdsatmospheres.nmsu.edu/data_and_services/atmospheres_data/MARS/curiosity/rems.html"),
    ("Mars Orbital Data Explorer (PDS Geosciences)", "MOLA, THEMIS, TES, CRISM, HiRISE.", "https://ode.rsl.wustl.edu/mars"),
]
FUENTES_MX = [
    ("CONABIO Geoportal", "Soils, climates, bioclimates, land use and regionalization.", "http://www.conabio.gob.mx/informacion/gis/"),
    ("CONANP – Federal protected natural areas", "Permit context (via CONABIO).", "http://geoportal.conabio.gob.mx/metadatos/doc/html/anpenero2024gw.html"),
    ("INEGI – Geology", "Lithology and structures.", "https://www.inegi.org.mx/temas/geologia/"),
    ("Mexican Geological Survey – GeoInfoMex", "1:250,000 geology.", "https://www.sgm.gob.mx/GeoInfoMexGobMx/"),
    ("Upper Gulf of California Biosphere Reserve (DOF)", "Protected area decree.", "https://sidof.segob.gob.mx/notas/docFuente/4745874"),
    ("Valle de los Cirios (Protected Planet)", "Flora and Fauna Protection Area.", "https://protectedplanet.net/301939"),
]
SOFTWARE = [
    ("QGIS 3.40", "Zone delineation, map algebra, zonal statistics and the Geospatial Suitability Index."),
    ("Python 3 · NumPy · Matplotlib · tifffile", "Reading rasters and GeoPackage, per-pixel statistics, indices, intervals and fact sheet generation."),
    ("NASA AppEEARS · Giovanni · Earthdata Search", "Download and preparation of satellite products."),
    ("Google Earth", "Visual inspection of the zones."),
    ("HTML · CSS · JavaScript", "Interactive fact sheets with no external dependencies."),
]


def fuentes_html():
    def lst(items):
        return "<ul>" + "".join(f"<li><b><a href='{e(u)}' target='_blank' rel='noopener'>{e(n)}</a></b> — {e(d)}</li>" for n, d, u in items) + "</ul>"
    return ("<div class='srcs'><div class='card' style='padding:24px 26px'><h4>Earth data (NASA)</h4>" + lst(FUENTES_DATOS) +
            "<h4 style='margin-top:22px'>Mars references</h4>" + lst(FUENTES_MARTE) +
            "<h4 style='margin-top:22px'>Official Mexican sources</h4>" + lst(FUENTES_MX) + "</div>"
            "<div class='card sw-list' style='padding:24px 26px'><h4>Software used</h4><ul>" +
            "".join(f"<li><span class='tag'>SW</span><b>{e(n)}</b><br>{e(d)}</li>" for n, d in SOFTWARE) + "</ul></div></div>")


def head(titulo):
    return ("<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<title>Aztroteca · {e(titulo)}</title><style>{fc.FICHA_CSS}{fd.EXTRA_CSS}{CSS2}</style></head><body>")


def foot(js_extra=""):
    return (f"<footer><div class='wrap'><div class='b'><img src='{LOGO}' alt='Logo Aztroteca' class='logo'>Aztroteca · Mars analogs in Mexico</div>"
            "<p>NASA Space Apps Challenge 2026 · NASA data and official Mexican sources</p></div></footer>"
            "<button id='up' type='button' aria-label='Back to top'></button><div id='tt' role='tooltip'></div><div class='tipbox'></div>"
            f"<script>{fc.FICHA_JS}{js_extra}</script></body></html>")


LOGO = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMcAAABgCAYAAACpHGaQAAAykklEQVR42u19eXgcV5Xv79xb1d1Sd2u1vEu24tghsSGATRIIixx2CAwB7AzwIKwzQ2C2BwPM8GYkMzCBx/LgEQKPhCUDM4AECSHBBAiRIGTFTuIgZ5FiS91aWmtvVdVd1V33nvdHd8sdWU5sx05ip8/31eek1V1dfe499+y/QzgFiJkJPT2Ens0EtBHQBWAAQJcmIn2s95uYmKhfvTpo2LZfp91ckwgZJvnCUKoQNM2AhFLSBwkiJQCDAR+SpQZYF5m1IanAWhTZ1L7O+0VDmE7R4Fw+nyqsfDjl0fbt/jH/RoDALADQY1+uXAQiMGr0lBE9IwUBfQLYQSUBGNBEu/TjfyYRdjPFVSx4JUOsYMXNmvUaQbIVxKvAaATDZCACsEEECZAEcwBEJpiLABVBKBLD12ABEANMh/499HVEkMwIEiAZZADMBHggFImowMwKoAIDOYB9gGaJkYLgOe3zlAzIjFaYh6FntJZTDQ3DGaInFihmFsCAKB0OhwSHiGpCc7oJBzNTX1+f2LGjjQDgSBuEmYNuenSVDzrDkIFNWqtO1rqThFjLzA3l90ghhM/MGQLSGpgD8wyBbBI8o5jnWLNjyOCMX8hb2pTFgBIF3xSu65re8uWZIrCxeDSaiJklMGoC9UZ2ohiUAT8gDNMsCBUQvg5AUKuUsplY1SnNywiilQl1IGojcBs0ohrcJoWQzExE5GvWSgo5r7WeZKJJQZiA0iOGGThYsJ3Z6OqNM2B+gmcC1YTmFBWOklZAxXRY0iRy5uJrREhuYZ9fxMznENEZENSifR8g5IUQM6x0jIV4VIBGij7HTCETdbY/Qx0d+VOJ+cxs2vZ0CwreMgixQgqs0Up3MGiNILRr5uVCiHpmDhCRL4hmla/GSYiDhiEeho+HPUljDQ2rZ4+C39zT08O7du3StW3/DBGOKlPgMGFIJg80RkLRc32/+GIinMeaN5Q0AScJNKFY3y8NOaiLhSFX+yPLlm3KHt33gap/28DAALq6uhjoA7CDgR709AA9PT2HnaxHc9qWN90S1ENAz2N5OzBA6Op6zMf7+vqwc+dOdTT827Nnj3nW2uYWYZjryOBOrbEBwGYStJpATUzUAK0tDUyYUhxkgb1SmMOu7z/S0LBm7ii0jK5pmKdQOKoEQlUzPp2ONYfMwEtZ8atIYCsYKxnssdaPgMTdSum7Ha/w0MqVG6af2HwYANBV5bAe3cZ+5vlXpXXo6+ujHTt2ABigik9xNCe948TX+K5eZ0i5RQrawqANRLRGs65nzRYDE8S4D1LcJ7R8oK5p5cGln6XfKLG0S9dMshMsHFUqnKs1RDY78ZwA8xshxesEUWfRVwUpxN2a0C8M485QaPnwke81QNUC8GxcsGoBKh8KBAB9fbP8eNrHceJryMOZmvT5RMZmQG8GI0pCFBg8LoA/Ecw9yvD2hMPrJhd/vr+/3wCArq7jiwjWhKNKS1Q7025m/CwS9E4GXQzQMs3qIZLyRgjx67q6FY8urQ0GCKidWscpPDQwMCC6SuYbE5Fa+r3TkVzGOxtCbAP4PGLaAqJGAnIkaJCZ7/KL+g+R5rWDiwWCud8oH1TPGjOMnpxQgCoLkUjcH26MLn+bJHmZIJyhlXoAEL2u9m9ubFw7fwRG87P1VHqqhKYq9KuW2tTZ7FCbqUNbWYjzBIkLiXgtgzQzP6wVfm8Y+rZgpH3f0fqRz3ami7LdX2Lu7MhzvNz0V4u5mUeLzswdhfzU30xODrUt1gz9/f0Gc7eocfDpFRhmFqW16DeWCizw0FDQSSfOy6XHPpW3Jm/w7MmH89mJB5zM2H/nM4n35nITHUv5K729vfLIgYrTXHNU/ICKpnDSk1uNgPFpZr5ACPT7BXyjvnHFHYscZ9SiIaeEhlkI9y42yZjjdXlLbiPGa0nQKzTrtQSaFITfkqAbA+HVe5ewCp495jFz7yFNMTd5tpeb/amXmx3L29P/J5c8uG7RyXTanSDPRu1S1ixy8d9te2RlLjP57nx24seenXg4lx5/wM1Ofj1vjb+KmY3FglI2v09XZpWiFoODvYG8Pfs115mbztlTX5+eHllZrSVOaybUhEUstdGZh4J5a+LVbnby62528n7PTjxYcBLfzluJi6oPyNI9ljbjTmmmAEDenn6Nl5t/xHPmf52dHXnOopOhpiWefcIil9Iqucz4Szx78quuk3ig4Ez92cslvprLjL94sRVS+jxOzX3DvYfMKNee+r+F3NxUzp5+T00oanSYoPT2yop1UU2F7OTLPTvxzWJu6sGCM3Wva09251OjnViUSzml9lHlREjHB1vc3PRdrj19hz0zuqpmPtXo6CKZjxWUwcHBgJudeEveTvzcy00fdJ2pXznZiUuqI5enxL5aEIzp2AbXSkzm7MS3FvseNarRURAtJSiOE1vt2tOfcnMz93u56f2eM/2Z3Px4e7Vw9VZZLc8oqQeAZPJAR96ayNjpeHdVXqOmLWp0Qn0UOz3x2rw9fZ1rT8dcZ+aHTnpy62M10DNESEo/oFcmEomwlYqPOZmxz5Re32PWfIsanch9VqnZqlB6On6ml5v+qufMPurlZnfn7YnXLEo4i2eEOWWn4r+wUvGfHxIM1ASjRict6FOtTVKpkSbXnv5kwZkdcp3Z291M4o1Pu09SeUBrPrbDTsbmOR6vqyXyavRUUXd392N8k6GhoaBrzfxdITf3kJebu9VKjb/yaYuSVmql7GT8oDUffwdwqFy5RjV6ukyuwcHeQM6a+p9ebv5Rz5n9pZudPGeJ0qSTT04q/hY7GRuqdsxrVKOn04Ff+P9EIuxZM//h5mbHvNzs16anByNVh/rJ1yJWKv5zJzXWU/7Smtao0TNOSFKp0c68PdPrOnMjeXvm/VjUlHXSaqesZHy/kxk7v6Y5avTMFJJDAmBnJl+fd+Ye9nJzt+bmh9urHPYTr0Xy6fiZVjJ+kNOx5scHD6jRUfpvNf6dZE3S399teLnZr7i5ual8duqDi3N1J4xy2djL7FT8wcqNa4t74soourtrzV0nK7oKANlk/OWeM3vQdRL/Xcmsn1Bn3UqNXmQnR/9cY/uTP9ns1PjzE4lHly9ezKc0uvLs0SIGAMTjd9Tl7alf5J2pB5Pl3qLD+0oWSu6rryc0xQxBlGGmOmYOEZFbRuCrde4dc682iFl/p621eWM+M/47JrqHtN9LRAcAAERgreWRwA9qdPRU3p8+M0siygN4cz4z+bn6QP192fnRNxHR7WUB0VU4BfpxNNGS3apGgfUBA4LddGwVgJEa6499oZiZhCCVmort9IvFfZqxkUBzwgz90rOnH2Hi74TCK39BRKoiTDVgghPC+wo/JRF92krG9weCwd842dg7ieiGyvtcd+4c8gvbtOINWiuDIFIUMu533fweIkpXhGTJg8tOxe+w0vF3LA6f1eg4KprnDr6m6KX91MyB98fj8bqCM325a8/c6eZm7/SsqXcsvL+/1hNzImnPnj0mAORTY9tzmTHHzoxfnMuMv6Tgzv4ml53wWaeZObtwaW+OXTsx4dmJr2TLgCBL7n0rGb/CTo9d/5RnH08/ATFKjmLsR8zMTmrsbQunlzP1F649c7vnzA7kshMXLtWfX6Mny//BQMmPHtvu2gllJ+OaVZrtVJytZMy3krFi1aVca5KZLS7kp+OZ5IGLF+9/AQBGXfAaaH5FuS9c13Idx02amSkgZU/BnZ/T0Nem5+LnAUAovPKGUGT5hdr3r5VG8BrXSlw9MbGnnminqvXKnCjfb7PPPBKSgi4XQhCD2c5kVNkEk0RkVF2iWCyylZz3wdweiTTemJ4dfRcRqUonLFVsLTsZu45Ac+GWjr9iZoOI/BrLjy+MS0Q6Ozf6YxJkAOiINBtdwOpi2fFTc0NDDZFVjV8m4pdqLl5eF23vfzzHsEZHh5BDtFNZc7FvR1pXfMhOTisQSaKjWjMlDYOkYbBfLLw03Nh+FzMLUfobkyT+mCa8x82OnE1Efk17HB8NDAyUEoFEtwJIEuh2O+V/lYiKAwMDxMxy2aZN2VB0xYcY+mME49p8ZmwXEamenh6q+SHH5+8R7VT51PgrI03RDznpGZ/E0QlGRav4xSIbhpSs1NU8WDLPqNpTzyZHuwWJHZHmji1l+1nVTrJjV+9ExLnkwXUM47p6wa+yFe4jwW8NN627rwr6XxKRbyUeXW5G6m/Qyp+ob+p4e0U4anw/dm1tJ+O/C0cj262spYWgY/blWGsVaW6WVjL51oZlndeL0kIIxdxvNLSs38XMOXs+dmXZrKrZwjiuGDzqmjvjTGzYMhggQZ8B0xdLf+sjImIi8vv7+43oqjNnQtHVLwYo4GTGb6s6sGoa5BgEI52ObSBBL8s5Dojo+KweEgwCCykvXXDISwfZgO7u7hbsem+EoPc46bG/IqIiM5u1JTiuBWPWSJMubos0d3wXRGuczNj5oJ26Uuqwfft2v9IKWt/U/maAx+302O/LAlar0zpKMxYApMK2+kjE1FprouPuYBXKdYkZL2IeChqHTrxduryos3ZqootZ3WlnxsaJaDczm0RUrC3F0VFfX19pcQS5zDpcimPhO5r1Jwl4K+/YUa1pdCW/RETvsFPxn9up+M+J6C1l07YWGHkcKo9dAEmxAVJWTvrjPdbI9xUAbrKnZZNYZBJoZpaR5jX3Mui1xPQzOzP2xpIG2VPTIEdJO3bs4HIoMACW8wDgS3wHwJa5uaG1VZndalOszPuOtwC83ErFrygHRmqm7VFhASFw4tDVSQhpSHGElLwRbW4fEJJfL4X873x24gNE24q13vKjMalKpSHMbDAo6sM/CABNTR1JQXRniAKVLLk8zFfp6WFmpgL7rwfzZU4y9hdlAaklCvFECSaVxOON2z1KkkKAiZ36ZaGsOIJT6TOzURdtH1BF9XIIcYVnTX2BiFS5lqi2WI+jmgHAshIbBSCamubGubu75D+w+ClIvL6ynofxvTT/T7S0bMgIKS5hom9bVmJ5Jdxe4+2SRiyXD6W9ft59suVP2giYDOYRohW2eJyoi8/9/UakpX2fb+eey4Q35LKJ30xPD0Yq2qW2MEs7dcxMpIqvVeBHiLYV8aY3SSLi+ubQ70Hclp0caqv4GkfS3OHG9rsZ/C0UC/9ZLlIUz4JGsXI5ea+sBCrKeLoGM8ul+2N2aGamtCPuzbtuPFQXAjMfX1Eng2EEiUC/OtbZHJTLTn7Pc2ZiFbgUInoM6PSzLZ/RWwZRZmajv39hupEBAHYqfpuTil9SWtihIDObzEx2On6rk4y9+fHq2KpbQ+1U7AErOfqu07HubSmQt2OdLFbNl1wq/k/MFmfnR4t2Ks7HclnJmM5bk34uM5GrQJQaTxy336nK2XImovfl0uOXmoHAD/O56R99/gtXfZx27lTPloRhmQ+iXOahASzZm5GZH3kxGKFwS8f15Zf8QzCY8ftBeCFz/26MjhrMfNik3LLpqkuhd/EhKP4R88T1AE6bfpuqEnEfADx7+vlaF1/CGhs16zMAbgKTEgbFiOSkIeS9hbx3FxFNVPfRVHo1mFmMjY1d2YLUByLR6FmObftEZByDr+iHIk2mk5q7ItLaMcbM8pjGng0MDMjt27f7tj2y0uDwtSywFlp9pC66agAoIUFs377dP/0K2gZk9bRcAMhmJ9tM0ueyj+dp6DMBtDLQRMwBJjqLABNMtzFxVggxQRCPKKXuB+mLiHFepGXdO48geAsTWxfq3tLxnzHzYLR5XfcR+w5OseYwItKJxP3hpvDyy4QQl2mtzgtFI6UcqFaA5lI6VMqF1/JOLiuF+J0AX2NGVu+uFrKFZOBsbFtdODRAQNjN530hhPEEz8MA/EjzMtNJz98Ybmq/BOgDsEPTk5B45O3E+4nMbq31rT4X/6mhYc3c4zaOnHpagqp/Ry4bfwWxeB0RbWOiDtZ6Qis1TSQOsKBhgGd0UdULIb4IgcuhhaGh2gOGsZmZ1yqtVwopm4jQpjVfL0jcK1nfnylYf25rO9s6fBPtN4HNOpud2CA13+Sq/NbW1o3WqVpe0t3dLXaVgg6w0vF3Bs1Aj1lfv5ELHhwnD4D9w2dVEpdTF2RIKUORMKA1igX/twU794nIis77FwSkt1fSzp0qOX3gpeFI5LpAfajNTqW5bNWUtfTC/RgAm6ZpBCONyGdTP59OFt+xfv16r8JfejJDFolIZTLjraYIfEkK8QrF6pt14au+XE4oPmbA5qk2QHLhAEiNdopA3fuZ+XVg7SqlDgB4iyr6FzS0dT68hEn1eiHkh6PNHW9e6v52MvYlYRhns1a7pTTPB/QGZgoSOKU1/1kT/46K2Bde1j7+WFTyeB8U74m0rvvCqVg1XTnZ4/E76pY1r/9GXbj+fb7rwXVdv8xvcRT34EqUL9LQIAsFz/UKhY81NHVcdUiDlKpz09NDG+qijV/USl0SikThpFMwTQNCCBARZCAAkEDBzU+y0l8JRVd/ubo27knNIV+sIZzM2PnSqPs8QS8H6SuC9St/uNRme3o0wIAAup7QJ6pmjJ0cO1eawY8JwouY+I9a+d+vb1hze3Z+9EIS4tPR5o43LIrYSfT1+farzr8ahMFIU8fXgGFjYGBClbO4RERFOxnrZ4HPRZvW3YKFuRWzq+HltkIYL2dWfy+l8RBYp0G0l4A/BFVhYLaol9cZ8r+iLetfVGkNLW0UYiLwqVCMOTc01BBZHb0pGI6+zE4lfYDF8dZBaa2VlFLWNzbCTqaviLZ2/EvFrO/t7ZU7d+5UAFBwJl+kNF2slf/PzJxisCtJ5IloPyTt9pKp65s6tiSXKvg0TlAPryCiuwFsd7PTb4eUn/Zy8x9l3/8SEf204rg+HT0L1c31j2fudXd3CyLS4w/e3bps3Yb/EIQLmfmnBe1/PBpZNVNZZCsZ3ymAfVXM9Cs9AT3799PHX3X+c/wiX1nmDW/fvklXNofjxNdwgZdFGgN3cn+/ga4uAKSI2iYBTNrJsbgGP7/g599uCuM8QxgXas1/UwyE/q2eigcNw+i0k7HLiOjaaiefud9A3yxjx45nXD9IZX8MDQ0ZdSvqbwiGIy+zkvNFIch8MmezEEJqrdlJp1WkpeWfrfmRQrS1s6fKByHs329SePWfnGRsNRNNaWlstSx2Vq9e7VXvg5PuBiyepZC3E+9zndl9Xm72bi838w4cNgvu5GE6VZ4jPRvbWnRTv3ftmU9nMg+2Hgl4bWFi6tBQMO/MDOayiQfmhoYaFsHrmKUWzNhNTjL2F9UhxMr9cskDHVYqdnflvZXXF5Dsk/F32en4DYvDsqUwb6900mPX2OnYpxb/HmcuviaXHv/LfHZyXzE/Hc9bE3d6duKreStx0eJQaLk3XTzTeusz8yPXMDucnR8tHGuY9YlCsE56rMCc4fR87NKF9SqnGFKJ0U4nNcZWOvbqwyCTnqCPX5zIE7pSmwUAdZFV3wuF285VungVIP7RdWb3us7M36dSI03bt2/3y35JabIoTuwckEqCLZunBz039x9CiucEjOV3uM7M31VQPxYxRRCRzi0LXiVlYJNfzP9w2aZNWWYOlU99Va5QlmAsl1I+XIm6MPcbGB4O9Pf3Gz6ZLxSgDBEVubdXliNOAhg1y/mQC6D1vSUe7ZdloaSSFtihtdbPZS12V3CZKrPAw8s6Juqb1v7Y9wv5Yq54oef6HwVxThA++5Lzz77TtRPfyFtTr+zt7ZW0fbtfXcz4dGbWKyeyk4pf0tDU/AEnPecLIcwTvNaktZaek9MB0/imMxdfAwC0c6eKx+N1Zp0YAPCZaNO631ZGGCysaYlXfOQaq5MfxwYAFN2ZNyiNfyBQJ4NvLvjONxoaDjm0paRXlz5ZkDWeNfU8luLbulhI1DWseesiwVB2MvYeCHofa/WIgPxzfXP7VZUQ7qEGpokOFuq6+kb1UqJO9zBnOz32Sda6Ndqy7hNHcMZvAel/ijR33ofDAOHGtgD8n5E57wJs3OhXoill30I56bH3Mfit0eZ1Fx/2u4jfSMB7yJBBv1j8FQv5g3B45V2POb37+kBlO/wpNKcwNbWvPhpqfjAQDLV7rsvH3WvxhI1K7Edamg07nf7PaHPHZTw4GHA7mv+kld4fbm5/5/EEMYyTiSm0yM/YDWC3bY8/3yDz8jojekMhNz1c9P2rf3nz7TdV8giVEOqT9U3S8XhLY3t7pvIcwejKBwBckMuM9zqp+C2RlnWvrDwb82DATtG/QZpvIcYnmXCAiJh7e7kSUmXmYno2tkxKTBB1usyZVtfOPo8gnw/QWb4qtkLr54MQsFOxVzCTCYIiRloIZDUjB6KzicUlmWSsnTVN+cBEa6uaJyLXzoy9gBj30KZN3mMWfc8ewtatBOC1YP4NM8vh4WFj48aNqhyifADAA9lkvMsk/IK0XiGkcZXnzLhMfJ2dy/yYiMaPBsTsBJMkIj+fir8j1NTYYSVTSghx0jL8JEjms1kG8zty2djVtk9fk8zDZcGQR0rYPq5f81QAbxERl0srRCSy9v5QeMVf5ZIzL9GKbzUM43+95eJX3O85U//bsxJbyuZZucCxMtD96EyDBRt/aCgoo3ytZ0/dk7cmr88705dXsInqG9fuZIJnJUe/WREcKxl9PwmMRKOrBgGcUSzoGWam/eecI0tde1sKRMSBgHFeqC70QisVu9m17N9DU7fv+y8EYYTBfSBSguhLROblQuCvBeEjwsC/+6z+i4gSYJaasVoAHzYNfCFEvDuXMe+yk7HfCSH+F0DPdTJj/2gnRy/OZifPnp19KErbthXL2rSd3cKPiEht2rTJq3RqDg4OBjx74oWCsKYuvOobdY3t/3bFF67axozPgbEtWt/4a9eZ+V7emnpV9XqcbCzfnp4ezczkM39QF30+SQrjMVtNKU1EJA0zdAsR/ljfuPbt5fKn4zoM6JmRXJt4mSHl+xj8MmZMMaPX8YrXLVvWMbEEgPBR/dDp6cFIY6hpjWZ6oTCNtwC0GYyfBMNtnwWAXHpsQoP+R7S5/VY7NXYPBLrDDWt/ncuM3SNYvb2uuXMUADKZ8dagGbhMFwsXGwHzuVrpIaXU5/NFfW/185WELHa3QfyXdc3rD0OOzGXGX6KU+li0Zd3bDv2mRDibVWtNv9iiSP5fw5SjWqkUa3SSEG1ErLTmPIMtAr2ANPcQ+M91wboDCC+frvDBmov9A0lsiDSv+9t4/I669vYXFxY0tzW1wgX3STPwHFXMD5EMXJf3nO82N3emq/jKJ9KcreQ0MjOPbjSCof0o1ZXxyd5vzKzr6+uFk3MGG1rWP7cU9Onh49WSxtPQY13tEFfqlG4DcNvc3FBDNBS5hECXRkLG3xWcqWGl1HVF0A1ENLtE7uKIPsqKFVtsAI+Urx9lMuObQmbgs15uaq/28pewND9AWnfPzsYeBnRduKHjt1ZiuFXUhbiuuXPUcWKrDdT9TyZ6NUg8AKJ/LeS9t7HmeHTZuhsBgLu7BXreJAGL0+n1EdIIqQDnq0xDxv79BjZvVnYq/iKAZ8u5EQmgQERO+flgpWKOl8v9c9OKjY8ubNrc/ErLczqlEJcB2KQFXkKgd+f8QpAyE34uPT6ntHpIGnI7K77ZshLLo9FS2HmB39GV03YyJkmrlzJRmwD9fTgUeU/enh4o5IpXEdHQSRASAUBL07ywPhox7XTWJ3pK9hoVCgUIovW5+eF2oo1j3d0LJTnPfOFY1P2mqjc70aYsgGsBXOvMxddw0LyEgHcFCZ/ynKmHwPzzIrzdRJSo7ocoO/NcrVVKwtdDQA8NDAxQY+PaIQA789mJDyoy7zJJXlRkPVNniP/DrO8EoGWAA1pzLm9N/Lug0NtYq1vcYu6tTU3rDgBAdj52qZCULW8kIiKfe0onUzodFxDIhsOBbCVaVCkgJCJlzceWQYhkuVcGhyJZYCDV4KTtZlMG88xsDAwMVPInEwAmrFT8fGJkoy0dHwMAnp6OeHWqHcDZGtjMijtJ0Kul9t+Qz457AA4IKWNF3/+jAC33lcqHSr9/CMDtljW1woD4x1B94AYvNzcArb5FRPtOtJAw0XNAlb1JT8WeIt/3dSQSjjhZnA1grKenh3bt2oVTSjiWStQd0iZ9IOqYAHAlgCvzqUSnDPDFDL5U+MYnXXsyDs2/8wX/KhJZe391UeBCAV9fH2NHjwbAXV1dlUWXRHSNnRyf8pX/UzAGws2tl+fS828jIm2nJt4QDAbOV34hli/YFzc1rTsIAPF4vK79wIGiRbQczKosmBVfSDCz9rITbT5rAla7VfmNcriXyUmPtTH4YWam/fv7RBU6O7sZu42ZVbjVmwOgurq6iJkFhodNTEyoHOEszXiglD/ZT0QrbAAPla/rrGTs4qxtbI9EUEe+OkdIeSYp9UIw/kYI8XxDIuCkx25kpgmSfC/n83+qW975qcHBwX87o6P1dmkEfuRak3coQVeXk7lPVkhK5Rea14E1iOip3EwahiGYdGvphYHj/nLjGQhroxaZXUxEIwC+DuDr9szoKmkEX6dZv8mEfK9rTeYA3AMhbg4qdRsRzR0Bbl5V7h1pWXuTPT+ipRn4WS49V4SgSScd/3+BuvAbvHz29khTx3uqP9jR0ZEvDxYNK0a6AoFfdV/YqZF6hpBLbKZiCT93tFmAUuXPFqo/ayXH6onYI1qIVFXMAK/c0xFh4qmlQC4ymYNnkabimjVrcgByAG4rX98r4/Z+UQhpCc0DMmBcwFq9jOqC785nx+vBNKr8Yiu0fw0Ia6QIXeM6s/cWvfyXiOhEzGwJgrlSPvJU7iSAnryqMp7h+E8KKJV2dHV1ia6uLl02qb4H4HsTExP1LQ38EiGM17LWH3eBz7v25AQR3VkoFgYM4AA4oAEXQAguXAQ5yIWib2rT/RO0vCkQCl2ildqtlP+rYj7zcdb423Q6dkYQJDywLn2UREAbRc1+GMTLU6nRTiIhmbUiEjLIWmnITmY28qnRTo9IwAUjBARBIq/9IoEamGhZPjXaCaqTYK1ARKy1YhQ7NchIT8XOQAgUBBgcYJAQee34BNEKrVtTqdHOEAkJNpVHBcGsFWl5NjObqdTI+hAJ6QEIAiiQNAJaFopceIHWxZ/5Qg7qQm6f1orrqb4RJq0jwpuFFC9jrS8UQjarQr6uvrHxPdD+pa41+YO8732jqWn9A4v7TY4J9uAUbu6lU7QfQFTnUlBVZmHUB7pY6Ys06+eCIZXWGlVLVCnSIwIxwwfRNmge0+CDArQaxB0MGka52UgIYq1LGVUwzgR4jkHZUq84VYxpJnCYgTUAHhUg1o/xAUkRsIGJs2Car0I9BBE0M0dAWCuYhnRlTQRYANAaGsQbiWmOwRmASAiwLoc1iKgeQDszHhECpDWj6rk0ETYxc5IBWxBJgBUzucw6BZAEYbNg3AJBnSTEeay1BhAIN7Ujlx6bKUCd1dS0PnMsZfLM/QbRdt9Oxb8Vbmr8azuVPqbGoye5P1SkISpzlv3WcHPH9U+mx8g4RREFF0yvvr4+sWPHDgJ6dNlP+a/yBWY29u7dS1sB7AWwdSuwdy+wdetWg4jy6dnRjwSD5gumUkNnd3Zud63Z0VeSIf81khNvwGpHARvVIaSQvdpOtf2Ctb56aHT+xq1bt4q9e/fqrVu30t69e/mcM9rO10RXjE5kX7kZADZvLplXo6MG1s8rJ9XWy+DdQwdnv9/a2irXr1/vDw8Py40bszpvtV2gFX3uoYMzr9y6dWu1WVX63nTb9cx87SMjsz/funWrAKAqn7VSy19M4CsizR1dw8PDYiMAbDRpZqbeWL58edFOj/1CCnlNfdPavoUNFI/XeU2BTg39VjCeq1nXSSFTWusD4YbGs9xczvWcqe8ppa/86te/n+3p6TnG/pGuim04/FSfv0Qk3FyOGWq0jGulTzuz6lgFZZFWoXL22D9CDL6YTB7oCJrmFSSkXNG2abeTGrtKsZ4CK4/WtOeqM8nMrIi2sZWMkZSG2LZtW5GZadu2bQwigBlOOu6x5sCWLVsKj/2+bk20S1vJmA9NtG3btiJ3d6sS0gj5AMNOjToAzG3bthWP8Nk8iAPl7xXlaJgGegD93lkIwUcC3bOSsbgi3uZkxl3DMF6itX+2q7EaYJNAD2vojIC4l4jOMMzQJs8rXu0XCl+Ltq7bX7nH0UZ7qpK1pd5w4n1cKOCpAodgZg4Gg+R5XiKbDzyyyH97dgnHEwtL9bHFAGAQUTGdjrdIjesI9KAgeb4qFkcAvqyuPrq5WHBtdmZXE9HkwkdHR4PMXHBScYcF6kuFkgOSAQWtCUTsCcPW7BfL31QWGdDevW+SjF1sAxkSCDNAe9/0Jsm7djFYE0CcnTMcIbXJzBJE+hD80n6DuUfZqfGMENxcClkPoKqHHcCuh6xkTM7OPhQNBhtDhl88i4V8HgFnAThTCHEusw4o1mdqpQ74Wv9EmPhDONwxMTc31FAfaLjFCAbeq4r5O1Wx+I5w0+q9jxetqhaAQ9cAFuWcKoJ6i5WMPRwKhZ7juq6mk50mJ1JmKCQLXuGPa9asyT3ZUvTTHl6np6ebenp6qLzQxfT00AaT6NdM/K1CoXiuYVJaMyeizR0fsDPjF0tpfN/T/i8L+dmHtOIfXvHFb9xMnaUiw+x8LCE0GyiXhJcFAARwhvWM0FqNjIyEqLNzAQiBt25lAthinhIk2ghYeK0kZEwUHE6yHwza0weX7envn+8qPauqRLXs+diwr3hVuQhS2NMjK5WBzoBhngWiLVrr50SM6ACz0iSlS0CciAZ97f9SkljuK/3XkeaOtx0qVkxsyVnTn5FCvBRC/NJz7O9GWzsGD01H2szAAAPlkPKhIshqx5yXLE/PT66xveJGIeRm1thEhDb9VEWsmIlZE4F/8Kx0yI+1+6z6tbw9835o9VmlCv+iGQcE0ecF++/UZPwq3NR+7tTUvkA40DSgBHaGAnVvFELsAHQImv9Q8JwfAMY7AR6Ltqz/xuJRZ5nMWINk3Aqj+NpI5IzZQ073fgPYrOxU/KNE2BRu6vj7ciVwYVEb7K3k493hckkKc7/hZs5Y57NoB+l3BaT58mLRv09IcQYz1wPICCFSmvUeYnodgBvrGsPfIGpOH25ajd5BZH5UGLxBiMCHAbRopa9TOef/RVdumD4Wvk5MTNSvbqa2fL6wVoE7jEDgLOX7G8FYLaRcwUCANadIIMmK9xMwosFfFkIYWjOITs6eY4aqq68T+ZzzcKR57lxgq/9kiyuN03zKq+FlJ84QhvF6DbGTAM/XhTdHmtftsZPxEbD+aH3LGTErGbOc5NhFK1ee+zs7PWYWCirf3LziSgBXFpzJbQriUiGDXzcD5pnK9x/1rKmkVvSnuqYVj1b5NUkrGXOFMBbnOgrlfMNeMF1Y7QdxaqTJYWOdETDW+sXCSkjxJTsVA4DVdgp1UgqTtU4KoqSvVFQI3CAlHnYVxRsb184vCNZ8LA9Bq4ia0xyP16G93Vso07FnVrngacM0fqYL3n0gfDNQ1/ZTIuI9e/aYnBlvtfOewfWiRbLRyMxN0GIFa9VCghqY0ElAM4BlAJlgFckXSGohXAKmtVIJghgmQTdoSY8qxbHG5vb5RQNZz65vbPqwlZz3iYRxso5DGQiQyLv/WoGuPZ5K3NNWcxwq2RgKOung90wzcKbWLKQpHykW9I/DjatuLDupPwWQjbasez8zUy4z/les+e2Rlo5XW8nY3ULg8vrGjvsXh4uddPyjhhH4hPL9e4hoEwnkGDylFQ8BHGONjzHwFSFpD5iVr5RhmjLgF/QyYYgLwbSTWd9MQmwkwGTWkXIP+BhAnQzMQvAPWfOo8mi00cMElROQ2fnYXp/8i1paNmSqbH9j//791Lk2+jxm+n6kuWNLpRvQO+/sN7Lmvybi1wfDzbBTsz6g72JQQRCtBCHEmjWVznLFDIOIfSaySCPFYEsIkdJaJyXRlNI8xkRTpghO5LU9V3mOxwu379+/X27evFlnxsYaAo1inxkIrHXzeUVE8gT3chQjLa2mk5rrjbSsv7QCsnDaJgGfzOAYYGORefzzWpIdClsTVZlnOOmx72qtV0eaOy6tRKTqG/1r7ZT8hDUf2wwgrmG0VJAsyja3QUQFZnV7oeD9Odqy7u2JRCLcEvE3EMkXaFIbWPGFJKVirT7BGqOsASkkKQWSUqSU4jQJEIFGlVY/D5k0UrCLs49MpFPbtm0r5tLxd2mtXxltWn/NYzfaHhM9N6qcoISAcQkz/2B4eNgon4r+li1bGMCe7PzoRMFJfET5aq1nBl8HXUwy868LnveTopfIC2EqQBKzyjOkq/2iEzDknDY5p7NFP7Iy7BCtco51Dh/QRuXQ7WK/RAFQZbCDZHZ+9C9lINBvGIZRLBa1EOKEOOdaaz/a1Gjmrcy+cHPkQ+X10jWf4xjIzYxthDSv1qpYGJ/Ov2njxo2Fx3YCjr4bEO9VWh2QUtwRbuq4tvK36k5ATf5Nlht48apVh2+kXCr+CUW8LNp0hE7AdPx3rPjvqsOklVzN6191wTlE/N/hJv0iYH1xUSegzqXGP6qht0db1l1SfU/PnnghmN5GUuwkEgW/WNwtBH4UjKy598klWSs1SV0oR6NKz9PTA/QcWxl4JWqUmnr0knBD9CfMbBZczy8PFD3usC0AP9LUZLq53LDjWhctW7ZpvBLqxgkqLT4tqdxcZeayoxe69sw3yQjeqMG/rm9sf82mcrddefyYYmYZaVn/AyYM10ebL2PFkdLij5rVUZa65qFJJiqETbejgmfLzJKHhoLM/YYPDLHGtipQBipdpb+DMczAxcwsBwcHA5Ww6I4dO3SkuX2QmTwnHTindPLtlRXBICIdbm7/OsBr0+nYhmwy/grPTny56Ez9kUl8m0HNvq/eb9Yt31zXsOafgpE195aAJPqN/v7StdCvz73yEFBzCf29qpe9MpJNEW33SxdV/lVEpGnXrmNuHCrxuN9oXnnm9V7OfqOQYi7S1GgwszpW0GdmZq11qUaueZnp5fO32fl0V0kweuXJarM+zSA8gXQ61py3Jm/y8nNXzM7GVj8R+sjQ0FAwb08P5q2pvamR+5qWRB9Jxm5yUvFLlkIfSaVG1lvJ+J7KoJ/K6xWEkOxc/ANWMvazxegjZUGRVjJ2jZ2OfXrx78mnp8/MZyc+mLcmH/acRCKXHr/TsxNfKWQnXrq4m68ssM/IQ4/LfJiaeuQMz5m6iVWKtTfLVjKmrGSsaKfivpWMaTsV19XoIlYqrqxkzLeSsaKTHmPWaXbtRDFvTV6xZ88Cr8WzvrbqRII+LOXMj4z0N61q2/xZCNGlfb9PEX+zuoEoOx/7GhHlIs3t/1Lpk14QhL4+Yb/q/DsA/0PRlg0PVGWziYg4nxpZryBuCDfp84FRv3SqHqr7sZLx5zLwJREIXkbaP5+02k4kthqmUVco+A9JU77aLxQ+FWle9/3FAnEywSlO1hq42cm3M9GnAgFjqwgEgWIBnleA7/sVswlCCDJNE2YwAEgDnuPkhRS/KLj5/x1pXn9vdedhTS0c62KUBscYR9OHXv0ez0pszllT33WdmX2uM/2dvDXWBQCZuZELrNToLyqb8tD8iJEQM0srFf++k4z/LTPLkZGR0MLMifIJZ6Xif8jOj15Y/b2ZmfFN1nzs0ux87MpcZjznZif2udmJ3zqZ8c/lrfFXjYyMhNJTsTOy87F9/RV4mT17TGYWfEoWj3ZXa2/K5xPbPTvx5Xx24k4nNTZvp+JczE2xZyfYSY97+cz4qGclfuk6U//gZmY2LtLoVKvKfZqwch0nvkZy4L0EuhjQ2ld+DIzXSMKLQ43tw4c53fPx17LAh6PNHW9Z6v5OKv45w5BnFXz/dsMwXwHmFQAHAEpopR4wpdydZ36oOo9RgvWJ9xLRg+Hm9p5TESv3aDU5Z8ZbbV+tFIaIosBKRILJUMibJCqFtKtNqJOtLWrCcQxAEAVn6gLlq9cLgW1MtJY1O0qrcQIOsuIUCAkQGQx8ThI+pjRaGLpVkFgphFivlGqSQjSQFCuI+UfMuE8IeU8sYQ1vWgzJwyz2799vbN68WWcy8Q5D0y2+wLbGxvbUqYqyfqQZigCXo2NHxjNeYjZKrZ/jGaFJBgYkLeoJSKfjLQEhNxP0OVpjg9a6lYjaCGRq5rMIaAbRbmaVJSHjpjQOeJ77ZxLiNcz6RQ2tnf/jcNjMAQJmGShh3lZ6EbLJ+I+JeTjauu5fT8cZKEvN7wD6qK9vYTIvn+6DkU6TuXVPHA2yk2PnWsn4HixdQv5FJxX7TNkXCS4VPaseN+dkxs63krH49PR05EjvrdHJIVFjwbHiAT8Gi7Z6oGMll2BGWtr3EWBZyZF3VmYCVvIaBLxAKd5X9hn8MogdL0InoFLmGWCtv03gT69YscKu5CFqK1GjU1W7GOVRBR+p5DQqsfjp6cGInYzvdw7lXOhI9yhjWe2ykrGbT8dhmTV69jrycDPjm+xUbB9zSWMwM9nz8dda8/E/PF7SamEy6vzohXYyPpXNTrbVzKmaWXW6GF8MAMGGNQeZSWVnQ+vKJRlMRG8nwm+OxHtmFkKQ4nS8RZP4GZje19CwerZmTtWE4zTxS8Dd3SxKNUmclYHABgCYmxtqYOiXSlI/BEpAy0slILVmshXfqoErI63tv+L+fuNUHz5aoxodFmmyUrGbrXRsZ/m//8FOxX+xlP9Qce4BwE7Gfmun4j+o9j1q9PRQjfkngfr6DukRoTlfDkFdrsEfKCW9+hb7KExE2krFdrMmN9rS8e5SvRRqGqNGpyfZqdg9tj26yk7F3msn479b7IiXBQDd3d3CSY/d4qTjNx6pcrhGNc1x2rTq2vb0Si64BjikiQvdIPHWRQDTkoj8XPJAB2TwJma+J9zU8cEqTVJzwGsO+enHU2YmFAqvAdED5Bd6QPh1pHntfRXAuXLkyned6bfBqLsLwLXhpvaaYNQ0B54NmXTOzo+8RkCuAFGD5c5fVMKDKmXE0+l4iynMrxPwfL9Y2NHQuv7206XStkY1erxZ7JSejp/p5maTdjJmeanx51e/J29Nf9TLzT3i2lNXDu3eHaz2PWpUo9O6dKSM0/QTZp/tdOw1lYYrLzfzl649c7frzNzqpCe3Ls6o16hGp3ULLgBkZkbf6HuZgjVzcEcqNdLk2olPevm5e1xnbsC1ExdX91PXIlK1+RzPlnoqzmTGNgSEfJCZ40R0m2GY52vNfy76xaujTWtveSq72GpUc8ifWczU+GZdpH4qZzt3ENFdBcv558iKzilU4VPVSkFq9Kyk9HRsw/T0YGSxucW9vbVy81OQ/j+GnDnI5qNQjAAAAABJRU5ErkJggg=="
BRAND = f"<img src='{LOGO}' alt='Logo Aztroteca' class='logo'>Aztroteca"


def clase_css(c):
    return {"High analog": "alto", "Medium-high analog": "medio", "Moderate analog": "mod"}.get(c, "bajo")


# --------------------------------------------------------------------------------------------
# Mapa de la zona con lugares de referencia
# --------------------------------------------------------------------------------------------
def mapa_zona(f, mapa, w=640, h=460):
    g = f["polys"]
    xs = [x for p in g for r in p for x, _ in r] + [L["lon"] for L in f["lugares"]]
    ys = [y for p in g for r in p for _, y in r] + [L["lat"] for L in f["lugares"]]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    mx, my = (x1 - x0) * .12 + .02, (y1 - y0) * .12 + .02
    x0, x1, y0, y1 = x0 - mx, x1 + mx, y0 - my, y1 + my
    k = math.cos(math.radians((y0 + y1) / 2))
    s = min(w / ((x1 - x0) * k), h / (y1 - y0))
    ox = (w - (x1 - x0) * k * s) / 2; oy = (h - (y1 - y0) * s) / 2

    def P(x, y):
        return ox + (x - x0) * k * s, oy + (y1 - y) * s

    def path(polys):
        return "".join("M" + "L".join("%.1f,%.1f" % P(x, y) for x, y in r) + "Z" for p in polys for r in p)
    nb = []
    for fid, gg in mapa["todas"].items():
        if fid == f["fid"]:
            continue
        bx = [x for p in gg for r in p for x, _ in r]; by = [y for p in gg for r in p for _, y in r]
        if not bx:
            continue
        if max(bx) >= x0 and min(bx) <= x1 and max(by) >= y0 and min(by) <= y1:
            nb.append(path(gg))
    o = [f"<svg viewBox='0 0 {w} {h}' class='zsvg' role='img' aria-label='Zone map'>",
         f"<path class='nb' d='{''.join(nb)}'/>",
         f"<path class='me' fill-rule='evenodd' d='{path(g)}' data-tt='<b>{e(f['nombre'])}</b>{f['area_km2']:,.0f} km²'/>"]
    for L in f["lugares"]:
        X, Y = P(L["lon"], L["lat"])
        nom = L["nombre"].split(" (")[0]
        anchor, dx = ("end", -11) if X > w * .65 else ("start", 11)
        o.append(f"<g class='lm' data-tt='<b>{e(nom)}</b>{L['lat']:.3f}°, {L['lon']:.3f}°'><circle cx='{X:.1f}' cy='{Y:.1f}' r='6'/>"
                 f"<text x='{X + dx:.1f}' y='{Y + 4:.1f}' text-anchor='{anchor}'>{e(nom)}</text></g>")
    # barra de escala
    km_px = s / 111.0
    paso = next(v for v in (1, 2, 5, 10, 20, 50, 100, 200) if v * km_px >= 60)
    o.append(f"<line class='scl' x1='20' y1='{h - 20}' x2='{20 + paso * km_px:.1f}' y2='{h - 20}'/><text class='sct' x='20' y='{h - 28}'>{paso} km</text>")
    o.append("</svg>")
    return "".join(o)


# --------------------------------------------------------------------------------------------
# Ficha
# --------------------------------------------------------------------------------------------
def ficha(f, mapa, N):
    i = f["dae"]; nota = f["nota"]; lo, hi = f["int"]["ambas"]; el, eh = f["ena_int"]
    clase = f["clase_nac"]
    H = [head(f"{f['nombre']} · Mars analog scientific fact sheet")]
    nav = [("resumen", "Summary"), ("fortalezas", "Strengths"), ("balance", "Pros and limitations"), ("confiabilidad", "Reliability"),
           ("ubicacion", "Location"), ("datos", "Data"), ("fuentes", "Sources")]
    H.append(f"<header class='top'><div class='wrap'><a class='brand' href='../index.html' style='text-decoration:none'>{BRAND}</a><nav class='nav'>"
             + "".join(f"<a href='#{a}'>{t}</a>" for a, t in nav) + "</nav></div></header>")
    # HERO
    H.append("<section class='hero' id='top'><div class='wrap'><div class='hgrid'><div>"
             f"<div class='kick'>Scientific fact sheet · Zone {f['rank_nota']} of 10</div>"
             f"<h1>{e(f['nombre'])}</h1><p class='desc'>{e(f['descripcion'])}</p><div class='chips'>"
             f"<span class='chip'>{f['lat']:.3f}° N, {abs(f['lon']):.3f}° W</span><span class='chip'>{f['area_km2']:,.0f} km²</span>"
             f"<span class='chip'>Extent {f['geo']['extension_km']:,.0f} km</span><span class='chip'>{len(f['lugares'])} reference {'locality' if len(f['lugares']) == 1 else 'localities'}</span></div>"
             f"<div class='cls'><i></i>{e(clase)} · National Scale {nota:.2f}/10</div></div>"
             "<div class='gauge'><svg viewBox='0 0 120 120'><defs><linearGradient id='gg' x1='0' y1='0' x2='1' y2='1'>"
             "<stop offset='0' stop-color='#e0782f'/><stop offset='1' stop-color='#c1440e'/></linearGradient></defs>"
             "<circle class='trk' cx='60' cy='60' r='54' fill='none' stroke-width='7'/>"
             f"<circle class='val' data-v='{(nota - 1) / 9:.4f}' cx='60' cy='60' r='54' fill='none' stroke-width='7'/></svg>"
             f"<div class='ctr'><div class='big' data-count='{nota:.2f}' data-dec='2'>{nota:.2f}</div>"
             "<div class='lab'>National Analogy Scale</div><div class='sub'>from 1 to 10</div></div></div></div>")
    kp = [("National Scale (NAS)", f"<span data-count='{nota:.2f}' data-dec='2'>{nota:.2f}</span><small>/10</small>", f"Interval {el:.2f}–{eh:.2f}", (nota - 1) / 9),
          ("Mars analogy (MAI)", f"<span data-count='{i:.1f}' data-dec='1'>{i:.1f}</span><small>%</small>", f"Interval {lo:.1f}–{hi:.1f} %", i / 100),
          ("GIS suitability (GSI)", f"<span data-count='{f['qgis_index']:.3f}' data-dec='3'>{f['qgis_index']:.3f}</span>", f"Rank {f['rank_qgis']} of {N}", (f["qgis_index"] - .73) / .08),
          ("Data quality", f"{f['confianza']:.0f}<small>%</small>", "Three indirect satellite variables", f["confianza"] / 100),
          ("Variable coverage", f"{f['cobertura']:.0f}<small>%</small>", "Index weight with data", f["cobertura"] / 100)]
    H.append("<div class='kpis k5'>" + "".join(
        f"<div class='kpi'><div class='l'>{t}</div><div class='v'>{v}</div><div class='d'>{e(d)}</div>{fc._bar(b, '')}</div>" for t, v, d, b in kp) + "</div></div></section><main class='wrap'>")

    # RESUMEN
    top = f["vars"][0]
    peor = min((v for v in f["vars"] if v["s"] is not None), key=lambda v: v["s"])
    resumen = [
        f"{f['nombre']} scores {nota:.2f} out of 10 on the National Analogy Scale: it outranks {f['pct_top']:.1f} % of the {N} candidate zones in Mexico and is classified as a {clase.lower()}.",
        f"Its Martian Analogy Index is {i:.1f} % ({clase_iam(i)} analog with respect to Mars), with a reliability interval of {lo:.1f} to {hi:.1f} %.",
        f"Its strongest variable is {lcf(VARS[top['k']]['nombre'])} ({top['valor']}). {top['pct_txt']}.",
        f"The largest difference from Mars is {lcf(VARS[peor['k']]['nombre'])}: {peor['valor']} versus {VARS[peor['k']]['ventana']} on Mars.",
    ]
    H.append("<section class='blk rv' id='resumen'><div class='sh'><div><div class='n'>01 · Summary</div><h2>How similar is it to Mars?</h2></div></div>"
             "<div class='why'><div class='card story'>" + "".join(f"<p>{e(x)}</p>" for x in resumen) + "</div>"
             "<div class='card ic'><div class='l'>National Analogy Scale</div>"
             f"<div class='v'>{nota:.2f}<small>/ 10</small></div>" + _escala_en(nota) +
             f"<p>The scale compares the zone with the country's {N} candidate zones, combining its Mars analogy and its geospatial suitability.</p></div></div></section>")

    # FORTALEZAS (variables)
    H.append("<section class='blk rv' id='fortalezas'><div class='sh'><div><div class='n'>02 · Strengths</div><h2>The site's strongest variables</h2></div>"
             "<p>Ordered from highest to lowest match with Mars. Tap a card to see what it measures and why it matters.</p></div><div class='vc-grid'>")
    for k, v in enumerate(f["vars"], 1):
        meta = VARS[v["k"]]
        s = v["s"]
        H.append(f"<div class='card vc'><span class='rk{' top' if k == 1 else ''}'>#{k}</span><h4>{e(meta['nombre'])}</h4><span class='src'>{e(meta['fuente'])}</span>"
                 f"<div class='nums'><b>{e(v['valor'])}</b><span>Mars: {e(meta['ventana'])}</span></div>"
                 f"<div class='two'><div>Match with Mars<br><b style='font:700 18px var(--disp);color:var(--ink);letter-spacing:0;text-transform:none'>{(f'{s * 100:.0f} %' if s is not None else 'Context')}</b>{fc._bar(s) if s is not None else ''}</div>"
                 f"<div>Position in Mexico<br><b style='font:700 18px var(--disp);color:var(--ink);letter-spacing:0;text-transform:none'>{v['pct']:.0f} %</b>{fc._bar(v['pct'] / 100, '')}</div></div>"
                 f"<div class='hint'>See explanation +</div><div class='more'><p><b>What it measures:</b> {e(meta['que'])}</p><p><b>On Mars:</b> {e(meta['marte'])}</p>"
                 f"<p><b>Why it matters:</b> {e(meta['porque'])}</p><p><b>In Mexico:</b> {e(v['pct_txt'])}.</p><p><b>Resolution:</b> {e(meta['res'])} · <b>Weight in the MAI:</b> {e(meta['peso'])}</p></div></div>")
    H.append("</div></section>")

    # BALANCE
    H.append("<section class='blk rv' id='balance'><div class='sh'><div><div class='n'>03 · Site assessment</div><h2>Pros and limitations</h2></div></div><div class='fv'>"
             "<div class='card fl ok'><h3><i></i>Pros</h3>" + "".join(f"<div class='it'><b>{e(a)}</b><span>{e(b)}</span></div>" for a, b in f["favor"]) + "</div>"
             "<div class='card fl bad'><h3><i></i>Limitations</h3>" + "".join(f"<div class='it'><b>{e(a)}</b><span>{e(b)}</span></div>" for a, b in f["limit"]) + "</div></div></section>")

    # CONFIABILIDAD
    ax = (max(0, min(f["int"]["ambas"][0], i) - 6), min(100, max(f["int"]["ambas"][1], i) + 6))
    zs = f["zonal"]
    ci = {"iam": i, "axis": ax, "espacial": f["int"]["espacial"], "pesos": f["int"]["pesos"], "ambas": f["int"]["ambas"],
          "txt": {"espacial": f"Using the low (P5) and high (P95) values of the zone's {zs['rango']['n']} pixels instead of the mean, the MAI ranges from {f['int']['espacial'][0]:.1f} to {f['int']['espacial'][1]:.1f} %.",
                  "pesos": f"If the precipitation and NDVI weights change by ±10 % (from 27 % to 33 %), the MAI ranges from {f['int']['pesos'][0]:.1f} to {f['int']['pesos'][1]:.1f} %.",
                  "ambas": f"Combining the variability within the zone and the weight changes, the MAI stays between {lo:.1f} and {hi:.1f} %. The corresponding National Scale goes from {el:.2f} to {eh:.2f}."}}
    H.append("<section class='blk rv' id='confiabilidad'><div class='sh'><div><div class='n'>04 · Reliability</div><h2>Reliability ranges</h2></div>"
             "<p>How much the result could change due to variation within the zone and to the weighting of the variables.</p></div>"
             "<div class='card ci'><div class='ci-tabs'><button type='button' data-k='ambas'>Combined</button><button type='button' data-k='espacial'>Variation within the zone</button>"
             "<button type='button' data-k='pesos'>Weight change ±10 %</button></div>"
             f"<div class='ci-plot'><span class='ax'></span><span class='bandx'></span><span class='ptx'></span><span class='lab' id='ci-lo'></span><span class='lab' id='ci-hi'></span></div>"
             f"<div class='ci-ax'><span>{ax[0]:.0f} %</span><span>MAI · central value {i:.1f} %</span><span>{ax[1]:.0f} %</span></div><p class='ci-txt' id='ci-t'></p></div>"
             "<div class='ci-grid'>"
             f"<div class='card'><div class='l'>Data quality</div><div class='v'>{f['confianza']:.0f} %</div><p>The three variables come from satellites and are indirect measurements of what is measured on Mars. A direct or field measurement counts as 100 %.</p></div>"
             f"<div class='card'><div class='l'>Variable coverage</div><div class='v'>{f['cobertura']:.0f} %</div><p>Share of the index's total weight that already has data. Unmeasured variables do not subtract points.</p></div>"
             f"<div class='card'><div class='l'>Resolution</div><div class='v'>{zs['rango']['n']} px</div><p>~1 km pixels inside the zone. With 4 or more pixels the value represents the site, not just the region.</p></div></div>"
             "<div class='sub2'><h3>Variation within the zone</h3><span>per-pixel statistics</span></div><div class='card list tbl-wrap'><table class='zt'>"
             "<tr><th>Variable</th><th>Pixels</th><th>Mean</th><th>Median</th><th>Low (P5)</th><th>High (P95)</th></tr>")
    for lab, kk, mult, nd in (("Precipitation (mm/day)", "precip", 1, 3), ("NDVI", "ndvi", 1, 3), ("Temperature range (°C)", "rango", 1, 1), ("Dust (× 10⁻⁸)", "polvo", 1e8, 2)):
        z = zs[kk]
        H.append(f"<tr><td>{lab}</td><td>{z['n']}</td>" + "".join(f"<td>{z[c] * mult:.{nd}f}</td>" for c in ("media", "mediana", "p5", "p95")) + "</tr>")
    H.append("</table></div></section>")

    # UBICACIÓN
    H.append("<section class='blk rv' id='ubicacion'><div class='sh'><div><div class='n'>05 · Location</div><h2>Where it is and how to get there</h2></div>"
             "<p>Hover over the points to see each locality's coordinates.</p></div>"
             f"<div class='zmap'><div class='card mapcard'>{mapa_zona(f, mapa)}</div><div><div class='card mapcard'>"
             + fd.svg_mapa(mapa, resaltar=f["fid"], puntos=mapa["puntos"]) +
             "<div class='mapcap'><span><i style='background:#c1440e'></i>This zone</span><span><i style='background:rgba(224,120,47,.5)'></i>Other top-10 zones</span></div></div>"
             "<div class='card list' style='margin-top:14px'>"
             + "".join(f"<div class='lr' style='grid-template-columns:1.4fr 1fr'><span class='k'>{e(L['nombre'].split(' (')[0])}</span><span class='m'>{L['lat']:.3f}°, {L['lon']:.3f}°</span></div>" for L in f["lugares"])
             + "</div></div></div></section>")

    # DATOS: Marte no reproducible + por medir
    lim = [r for r in f["matriz"] if r["Categoria"] == "Limitante"]
    pend = [r for r in f["matriz"] if r["Rol"] in ("Directa", "Categórica") or (r["Rol"] == "Proxy" and r["Variable"] not in ("Precipitación media", "NDVI", "Amplitud térmica diaria"))]
    grupos = {"Terrain and soil": ["Pendiente", "Cobertura de rocas", "Tamaño", "Densidad", "Cohesión", "Ángulo", "Capacidad", "Hundimiento", "Textura"],
              "Chemistry and water": ["Percloratos", "Azufre", "Actividad", "pH", "Contenido de agua", "recurso hídrico", "Mineralogía", "Litología"],
              "Climate and energy": ["Temperatura", "Irradiancia", "viento", "Albedo", "potencia", "Opacidad", "Tormentas", "eólicos"],
              "Biology and subsurface": ["Extremófilos", "Biofirmas", "cavidad", "tubo", "techo", "Estabilidad", "compresión"]}

    def grupo(v):
        for gname, keys in grupos.items():
            if any(kk.lower() in v.lower() for kk in keys):
                return gname
        return "Other"
    por = {}
    for r in pend:
        por.setdefault(grupo(r["Variable"]), []).append(r)
    H.append("<section class='blk rv' id='datos'><div class='sh'><div><div class='n'>06 · Data</div><h2>What remains to be measured and what Earth cannot reproduce</h2></div>"
             "<p>These variables will complete the index with official layers or fieldwork. Mars's planetary conditions are declared as limits of any terrestrial analog.</p></div>"
             "<div class='card' style='padding:26px 28px'><div class='pending'>")
    for gname, rs in por.items():
        H.append(f"<div class='pg'><h5>{e(gname)}</h5><ul>" + "".join(
            f"<li><b>{e(VT(r['Variable']))}</b><span>Mars: {e(RT(r['Variable']))} · {e(MT(r['Variable']))}</span></li>" for r in rs) + "</ul></div>")
    H.append("</div></div><div class='sub2'><h3>Mars conditions no terrestrial site can reproduce</h3><span>limits of the analogy</span></div><div class='grid3'>")
    for r in lim:
        H.append(f"<div class='card lim'><div class='t'><span>{e(VT(r['Variable']))}</span></div><div class='mv'>{e(RT(r['Variable']))}</div><div class='ml'>Value on Mars</div></div>")
    H.append("</div></section>")

    H.append("<section class='blk rv' id='fuentes'><div class='sh'><div><div class='n'>07 · Sources</div><h2>Sources and software</h2></div></div>" + fuentes_html() + "</section></main>")
    H.append(foot("window.__CI=" + json.dumps(ci, ensure_ascii=False) + ";" + JS_FICHA))
    return "".join(H)


# --------------------------------------------------------------------------------------------
# Índice
# --------------------------------------------------------------------------------------------
def mapa_interactivo(mapa, fichas, w=900, h=640):
    svg = fd.svg_mapa(mapa, etiquetas={f["fid"]: str(f["rank_qgis"]) for f in fichas}, w=w, h=h, puntos=mapa["puntos"])
    # reemplaza el trazo conjunto del top por trazos individuales con tooltip y enlace
    todas = mapa["todas"]
    xs = [x for g in todas.values() for p in g for r in p for x, _ in r]; ys = [y for g in todas.values() for p in g for r in p for _, y in r]
    x0, x1, y0, y1 = min(xs) - .3, max(xs) + .3, min(ys) - .3, max(ys) + .3
    k = math.cos(math.radians((y0 + y1) / 2)); s = min(w / ((x1 - x0) * k), h / (y1 - y0))
    ox = (w - (x1 - x0) * k * s) / 2; oy = (h - (y1 - y0) * s) / 2
    piezas = []
    for f in fichas:
        d = "".join("M" + "L".join(f"{ox + (x - x0) * k * s:.1f},{oy + (y1 - y) * s:.1f}" for x, y in r) + "Z" for p in todas[f["fid"]] for r in p)
        tt = f"<b>Zone {f['rank_qgis']} · {e(f['nombre'])}</b>NAS {f['nota']:.2f}/10 (rank {f['rank_nota']}) · MAI {f['dae']:.1f} %<br>Click to open the fact sheet"
        piezas.append(f"<path class='z-top' d='{d}' data-tt=\"{e(tt)}\" data-href='fichas/{f['fid']}.html'/>")
    for f in fichas:
        for L in f["lugares"]:
            X = ox + (L["lon"] - x0) * k * s; Y = oy + (y1 - L["lat"]) * s
            tl = f"<b>{e(L['nombre'].split(' (')[0])}</b>Zone {f['rank_qgis']} · {L['lat']:.3f}°, {L['lon']:.3f}°"
            piezas.append(f"<circle class='z-pl' cx='{X:.1f}' cy='{Y:.1f}' r='3.2' data-tt=\"{e(tl)}\"/>")
    svg = svg.replace("<path class='z-top' d='", "<path class='z-top' style='display:none' d='", 1)
    import re as _re
    lbls = "".join(_re.findall(r"<g class='lbl'>.*?</g>", svg))
    svg = _re.sub(r"<g class='lbl'>.*?</g>", "", svg)
    return svg.replace("</svg>", "".join(piezas) + lbls + "</svg>", 1).replace("class='map'", "class='map imap'", 1)


def indice(fichas, mapa, N):
    fs = sorted(fichas, key=lambda f: f["rank_nota"])
    rank_iam = {f["fid"]: k for k, f in enumerate(sorted(fichas, key=lambda f: -f["dae"]), 1)}
    Z = [{"nombre": f["nombre"], "fid": f["fid"], "ena": f["nota"], "iam": f["dae"], "iig": f["qgis_index"], "sP": f["sP"], "sN": f["sN"], "sT": f["sT"],
          "P": f["P"], "N": f["Nd"], "T": f["T"], "area": f["area_km2"], "rank_iam10": rank_iam[f["fid"]]} for f in fs]
    n_alto = sum(1 for f in fichas if f["nota"] >= 9)
    H = [head("Mars analogs in Mexico · Scientific fact sheets")]
    H.append(f"<header class='top'><div class='wrap'><div class='brand'>{BRAND}</div><nav class='nav'>"
             "<a href='#que-es'>About</a><a href='#ranking'>Ranking</a><a href='#mapa'>Map</a><a href='#comparar'>Compare</a><a href='#simulador'>Simulator</a>"
             "<a href='#datos'>Data</a><a href='#limitaciones'>Limitations</a><a href='#fuentes'>Sources</a></nav></div></header>")
    H.append("<section class='hero'><div class='wrap'><div class='hgrid'><div><div class='kick'>Aztroteca · NASA Space Apps Challenge 2026</div>"
             "<h1>Mars analogs in Mexico</h1>"
             f"<p class='desc'>Ten sites in northwestern Mexico assessed against Martian conditions, using NASA satellite data and official Mexican sources.</p>"
             f"<div class='chips'><span class='chip'>{N} candidate zones analyzed</span><span class='chip'>Baja California · Baja California Sur · Sonora</span></div></div>"
             "<div class='gauge'><svg viewBox='0 0 120 120'><defs><linearGradient id='gg' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#e0782f'/><stop offset='1' stop-color='#c1440e'/></linearGradient></defs>"
             f"<circle class='trk' cx='60' cy='60' r='54' fill='none' stroke-width='7'/><circle class='val' data-v='{n_alto / 10:.4f}' cx='60' cy='60' r='54' fill='none' stroke-width='7'/></svg>"
             f"<div class='ctr'><div class='big' data-count='{n_alto}'>{n_alto}</div><div class='lab'>of 10 · high analog</div><div class='sub'>National Analogy Scale</div></div></div></div>"
             "<div class='kpis'>"
             f"<div class='kpi'><div class='l'>Top site</div><div class='v' style='font-size:24px'>{e(fs[0]['nombre'])}</div><div class='d'>NAS {fs[0]['nota']:.2f}/10</div></div>"
             f"<div class='kpi'><div class='l'>Highest MAI</div><div class='v'>{max(f['dae'] for f in fichas):.1f}<small>%</small></div><div class='d'>{e(max(fichas, key=lambda f: f['dae'])['nombre'])}</div></div>"
             f"<div class='kpi'><div class='l'>Area assessed</div><div class='v'>{sum(f['area_km2'] for f in fichas):,.0f}<small>km²</small></div><div class='d'>10 zones</div></div>"
             f"<div class='kpi'><div class='l'>Reference localities</div><div class='v'>{sum(len(f['lugares']) for f in fichas)}</div><div class='d'>all inside their zone</div></div>"
             "</div></div></section><main class='wrap'>")
    # QUÉ ES
    H.append("<section class='blk rv' id='que-es'><div class='sh'><div><div class='n'>01 · About</div><h2>How we measure analogy with Mars</h2></div></div>"
             "<p class='lead-x'>A terrestrial analog is a place on Earth with conditions similar to those of another planet. It is used to test rovers, habitats, suits and instruments before going to Mars. "
             "Each site is assessed with three complementary indicators.</p><div class='defs' style='margin-top:24px'>"
             "<div class='card def'><div class='ac'>MAI</div><h4>Martian Analogy Index</h4><p>Measures, from 0 to 100 %, how close the conditions measured at the site are to the Mars reference ranges.</p>"
             "<p>Each variable scores 100 % if it falls within the Martian range and decreases gradually as it moves away.</p><div class='rg'>High ≥ 80 % · Moderate 60–80 % · Partial 40–60 %</div></div>"
             f"<div class='card def'><div class='ac'>NAS</div><h4>National Analogy Scale</h4><p>Ranks each site, from 1 to 10, against Mexico's {N} candidate zones.</p>"
             "<p>Combines the site's position in the MAI and in the Geospatial Suitability Index: 10 means it outranks all others.</p><div class='rg'>High ≥ 9 · Medium-high 7–9 · Moderate 5–7 · Low &lt; 5</div></div>"
             "<div class='card def'><div class='ac'>GSI</div><h4>Geospatial Suitability Index</h4><p>Result of the QGIS spatial analysis that delineated the candidate zones by combining rainfall, vegetation, temperature and dust.</p>"
             "<p>Higher values indicate zones more suitable as analogs.</p><div class='rg'>Scale 0 to 1</div></div></div>"
             "<div class='explain'><div class='card step'><div class='k'>1</div><h4>Satellite data</h4><p>Precipitation, vegetation, surface temperature and dust from NASA products at ~1 km.</p></div>"
             "<div class='card step'><div class='k'>2</div><h4>Comparison with Mars</h4><p>Each variable is compared with its Martian reference range for human exploration zones.</p></div>"
             "<div class='card step'><div class='k'>3</div><h4>Indices and reliability</h4><p>MAI, NAS and GSI are calculated, together with a reliability interval for each site.</p></div></div></section>")
    # RANKING
    H.append("<section class='blk rv' id='ranking'><div class='sh'><div><div class='n'>02 · Ranking</div><h2>The 10 sites</h2></div>"
             "<p>Tap a header to sort. Filter by class or open a fact sheet.</p></div>"
             "<div class='tools'><button type='button' class='tbtn fchip' data-c='alto' style='--c:var(--ok)'><span class='dot'></span>High analog</button>"
             "<button type='button' class='tbtn fchip' data-c='mod' style='--c:var(--mid)'><span class='dot'></span>Moderate analog</button></div>"
             "<div class='card list tbl-wrap'><table class='tbl' id='rank'><thead><tr>"
             "<th data-k='r'>#<span class='ar'></span></th><th data-k='n'>Site<span class='ar'></span></th><th data-k='ena'>NAS<span class='ar'></span></th>"
             "<th data-k='iam'>MAI<span class='ar'></span></th><th data-k='ci'>MAI interval</th><th data-k='iig'>GSI<span class='ar'></span></th>"
             "<th data-k='ndvi'>NDVI<span class='ar'></span></th><th data-k='p'>Rain<span class='ar'></span></th><th data-k='a'>Area km²<span class='ar'></span></th><th>Class</th></tr></thead><tbody>")
    for f in fs:
        lo, hi = f["int"]["ambas"]
        H.append(f"<tr data-r='{f['rank_nota']}' data-n='{e(f['nombre'])}' data-ena='{f['nota']:.4f}' data-iam='{f['dae']:.4f}' data-iig='{f['qgis_index']:.5f}' data-ndvi='{f['Nd']:.5f}' data-p='{f['P']:.5f}' data-a='{f['area_km2']:.2f}' data-cls='{clase_css(f['clase_nac'])}'>"
                 f"<td>{f['rank_nota']:02d}</td><td class='nm'><a href='fichas/{f['fid']}.html'>{e(f['nombre'])} →</a></td><td><b>{f['nota']:.2f}</b></td><td>{f['dae']:.1f} %</td><td>{lo:.1f}–{hi:.1f}</td>"
                 f"<td>{f['qgis_index']:.3f}</td><td>{f['Nd']:.3f}</td><td>{f['P']:.2f}</td><td>{f['area_km2']:,.0f}</td><td><span class='cl {clase_css(f['clase_nac'])}'>{e(f['clase_nac'].replace(' analog', ''))}</span></td></tr>")
    H.append("</tbody></table></div><div class='sub2'><h3>Two readings of analogy</h3><span>national position versus Mars analogy</span></div>"
             f"<div class='card mapcard'>{fd.scatter(fichas).replace('DAE frente a Marte', 'MAI (%)').replace(', DAE ', ', MAI ').replace('Nota nacional frente a DAE', 'National scale versus MAI').replace(': nota ', ': NAS ').replace('Nota nacional DAE-MX (1–10) · franja verde = análogo alto', 'National Analogy Scale (1–10) · green band = high analog')}</div></section>")
    # MAPA
    H.append("<section class='blk rv' id='mapa'><div class='sh'><div><div class='n'>03 · Map</div><h2>Site locations</h2></div>"
             f"<p>Numbers = zones 1 to 10 of the zone document (Geospatial Suitability Index order). White dots = reference localities. Hover for details and click to open the fact sheet.</p></div>"
             f"<div class='card mapcard'>{mapa_interactivo(mapa, fichas)}</div></section>")
    # COMPARADOR
    H.append("<section class='blk rv' id='comparar'><div class='sh'><div><div class='n'>04 · Compare</div><h2>Compare two sites</h2></div>"
             "<p>In green, the most favorable value for a Mars analog.</p></div>"
             "<div class='card cmp'><div class='sel'><select id='cA' aria-label='Site A'></select><span class='vs'>VS</span><select id='cB' aria-label='Site B'></select></div><div id='cmpres'></div></div></section>")
    # SIMULADOR
    H.append("<section class='blk rv' id='simulador'><div class='sh'><div><div class='n'>05 · Simulator</div><h2>What if the weights change?</h2></div>"
             "<p>Adjust the importance of each variable and watch how the MAI and the site order change.</p></div>"
             "<div class='sim'><div class='card ctl'><label>Precipitation <b id='vP'>30 %</b></label><input type='range' id='wP' min='0' max='80' value='30'>"
             "<label>Vegetation (NDVI) <b id='vN'>30 %</b></label><input type='range' id='wN' min='0' max='80' value='30'>"
             "<label>Temperature range <b id='vT'>40 %</b></label><div class='bar'><i style='width:100%'></i></div>"
             "<p class='note'>The temperature range takes the remaining weight. Reference values: 30 % · 30 % · 40 %.</p>"
             "<button type='button' class='btn' id='wreset' style='margin-top:10px'>Reset</button></div><div class='card res' id='simres'></div></div></section>")
    # DATOS
    H.append("<section class='blk rv' id='datos'><div class='sh'><div><div class='n'>06 · Data</div><h2>Variables assessed</h2></div>"
             "<p>Data are currently available for four satellite variables. Another 34 comparable variables will be added with official layers and fieldwork.</p></div><div class='vc-grid'>")
    for kk, meta in VARS.items():
        H.append(f"<div class='card vc open' style='cursor:default'><h4>{e(meta['nombre'])}</h4><span class='src'>{e(meta['fuente'])} · {e(meta['res'])}</span>"
                 f"<div class='more' style='display:block'><p><b>What it measures:</b> {e(meta['que'])}</p><p><b>On Mars:</b> {e(meta['marte'])}</p><p><b>Why it matters:</b> {e(meta['porque'])}</p>"
                 f"<p><b>Weight in the MAI:</b> {e(meta['peso'])}</p></div></div>")
    H.append("</div></section>")
    # LIMITACIONES GENERALES
    lims = ["The results use four satellite variables. Geology, soil, mineralogy, slope and caves have no data yet and may change the result.",
            "The temperature range of every site (9 to 19 °C) is far from Mars's 40 °C, so no site reaches 80 % MAI with the current data.",
            "Satellite values are ~1 km per-pixel averages; they do not replace field measurements.",
            "Mars's gravity, pressure, atmospheric composition, radiation and day length cannot be reproduced at any terrestrial site.",
            "Several sites lie within or next to protected natural areas; any activity requires confirming permits with CONANP."]
    H.append("<section class='blk rv' id='limitaciones'><div class='sh'><div><div class='n'>07 · Limitations</div><h2>Scope of the results</h2></div></div>"
             "<div class='card notes'><ul>" + "".join(f"<li>{e(x)}</li>" for x in lims) + "</ul></div></section>")
    H.append("<section class='blk rv' id='fuentes'><div class='sh'><div><div class='n'>08 · Sources</div><h2>Sources and software</h2></div></div>" + fuentes_html() + "</section></main>")
    H.append(foot("window.__Z=" + json.dumps(Z, ensure_ascii=False) + ";" + JS_INDEX))
    return "".join(H)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--resumen", type=Path, required=True)
    ap.add_argument("--matriz", type=Path, required=True)
    ap.add_argument("--qgis", type=Path, required=True)
    ap.add_argument("--salida", type=Path, default=Path("sitio"))
    a = ap.parse_args()
    fichas, otras, mapa, N = fd.preparar(a)
    a_ingles(fichas)
    enriquecer(fichas, a)
    (a.salida / "fichas").mkdir(parents=True, exist_ok=True)
    for f in fichas:
        (a.salida / "fichas" / f"{f['fid']}.html").write_text(ficha(f, mapa, N).replace("Mapa de zonas candidatas", "Map of candidate zones"), encoding="utf-8")
    (a.salida / "index.html").write_text(indice(fichas, mapa, N).replace("Mapa de zonas candidatas", "Map of candidate zones"), encoding="utf-8")
    datos = [{k: v for k, v in f.items() if k not in ("polys", "matriz", "zonal")} for f in fichas]
    (a.salida / "datos.json").write_text(json.dumps(datos, ensure_ascii=False, indent=1, default=float), encoding="utf-8")
    for f in sorted(fichas, key=lambda f: f["rank_nota"]):
        print(f"{f['rank_nota']:>2} {f['nombre'][:36]:<36} ENA {f['nota']:.2f} [{f['ena_int'][0]:.2f}-{f['ena_int'][1]:.2f}]  IAM {f['dae']:.1f} [{f['int']['ambas'][0]:.1f}-{f['int']['ambas'][1]:.1f}]  favor {len(f['favor'])} lim {len(f['limit'])}")


if __name__ == "__main__":
    main()
